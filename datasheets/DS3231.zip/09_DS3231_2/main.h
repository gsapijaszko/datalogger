#ifndef NATRYSK_H_
#define NATRYSK_H_
//Dodajemy standardowe biblioteki
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <avr/wdt.h>
#include <avr/pgmspace.h>
//Dodajemy nasze biblioteki
#include "LCD/lcd.h"
#include "LCD/LCDbuf.h"
#include "TIMERY/opoznienie.h"
#include "TIMERY/tajmer2.h"
#include "TIMERY/tajmer1.h"
#include "NapisyFlash/NapisyFlash.h"
#include "WODOTRYSKI/val_conv.h"
#include "WODOTRYSKI/triggery.h"
#include "WEWY/set_IO.h"
#include "EEPROM/PamiecUstawien.h"
#include "Menu/Menu.h"
//#include "I2C_SOFT/RTC.h"
// zast�piona przez I2C_TWI Kardasia
/*************************************************************************/
/*
 * Definiujemy sobie przyjazne nazwy dla naszych licznik�w programowych.
 */
#define L_16_1					Licznik_16_1
#define L_16_2					Licznik_16_2
#define L_16_3					Licznik_16_3
#define L_16_4					Licznik_16_4
#define L_16_5					Licznik_16_5
#define L_16_6					Licznik_16_6
#define L_16_7					Licznik_16_7
#define L_16_8			 		Licznik_16_8
/******************************************************************************/
#define L_dwukropek				Licznik_8_1
#define L_MiganieDiodaBlue		Licznik_8_2
#define L_DataCzas				Licznik_8_3
#define L_MiganieNapisDolny		Licznik_8_4
#define L_animacja 				Licznik_8_5
#define L_InkrementacjaZmiennej	Licznik_8_6
#define L_8_7					Licznik_8_7
#define L_buzz					Licznik_8_8
/******************************************************************************/
#define L_8a_1					Licznik_8a_1
#define L_8a_2					Licznik_8a_2
#define L_8a_3					Licznik_8a_3
#define L_8a_4					Licznik_8a_4
#define L_8a_5					Licznik_8a_5
#define L_8a_6					Licznik_8a_6
#define L_8a_7					Licznik_8a_7
#define L_8a_8					Licznik_8a_8
/******************************************************************************/
/*
 * Definiujemy flagi bitowe, z kt�rych korzysta� b�dziemy w programie.
 * Jest to znacznie mniej zasobo�erny spos�b obs�ugi zmiennych "bool".
 * Zwyk�e zdefiowanie zmiennej jako bool skutkuje i tak stworzeniem dla niej
 * zmiennej uint8_t. Dzi�ki zastosowaniu flag bitowych niwelujemy ten problem.
 * Dla 24 flag zarezerwowane zostan� tylko 3 bajty.
 */
struct {
   unsigned int f1 : 1;
   unsigned int f2 : 1;
   unsigned int f3 : 1;
   unsigned int f4 : 1;
   unsigned int f5 : 1;
   unsigned int f6 : 1;
   unsigned int f7 : 1;
   unsigned int f8 : 1;
   unsigned int f9 : 1;
   unsigned int f10 : 1;
   unsigned int f11 : 1;
   unsigned int f12 : 1;
   unsigned int f13 : 1;
   unsigned int f14 : 1;
   unsigned int f15 : 1;
   unsigned int f16 : 1;
   unsigned int f17 : 1;
   unsigned int f18 : 1;
   unsigned int f19 : 1;
   unsigned int f20 : 1;
   unsigned int f21 : 1;
   unsigned int f22 : 1;
   unsigned int f23 : 1;
   unsigned int f24 : 1;
} flaga;
/*
 * Definiujemy przyjazne nazwy dla naszych flag.
 */
#define	F_AktualizujRTC			flaga.f4
#endif
