#ifndef Wyjscia_H
#define Wyjscia_H
#include "../../MACRO_PORT.h"
#include "wyjscia_libr_conf.h"
//Definicja przyporzadkowania WYJSC
#if Wyjscie1_Aktywne==1		//Wyjscie 1
#define WY1_bit 			5
#define WY1_port 			PORTD
#endif
//*************************
#if Wyjscie2_Aktywne==1		//Wyjscie 2
#define WY2_bit 			2
#define WY2_port 			PORTC
#endif
//*************************
#if Wyjscie3_Aktywne==1		//Wyjscie 3
#define WY3_bit 			7
#define WY3_port 			PORTD
#endif
//*************************
#if Wyjscie4_Aktywne==1		//Wyjscie 4
#define WY4_bit 			4
#define WY4_port 			PORTB
#endif
//*************************
#if Dred_Aktywne==1			//Wyjscie dioda czerwona
#define LEDR_bit 			3
#define LEDR_port 			PORTC
#endif
//*************************
#if Dblue_Aktywne==1		//Wyjscie dioda niebieska
#define LEDB_bit 			4
#define LEDB_port 			PORTC
#endif
//*************************
#if Out230_Aktywne==1		//Wyjscie triakowe 230V
#define OUT_bit 			4
#define OUT_port 			PORTD
#endif
//*************************
#if dir485_Aktywne==1		//Wyjscie kierunku mgistrali 485
#define RS485_bit 			2
#define RS485_port 			PORTB
#endif
//*************************
#if Buzz_Aktywne==1			//Wyjscie buzzera
#define BUZZ_bit 			5
#define BUZZ_port 			PORTB
#endif
//***************************************************************************
#if Wyjscie1_Aktywne==1
#define WY1_pin PIN(WY1_port)
#define WY1_ddrb DDR(WY1_port)
#endif
#if Wyjscie2_Aktywne==1
#define WY2_pin PIN(WY2_port)
#define WY2_ddrb DDR(WY2_port)
#endif
#if Wyjscie3_Aktywne==1
#define WY3_pin PIN(WY3_port)
#define WY3_ddrb DDR(WY3_port)
#endif
#if Wyjscie4_Aktywne==1
#define WY4_pin PIN(WY4_port)
#define WY4_ddrb DDR(WY4_port)
#endif
#if Dred_Aktywne==1
#define LEDR_pin PIN(LEDR_port)
#define LEDR_ddrb DDR(LEDR_port)
#endif
#if Dblue_Aktywne==1
#define LEDB_pin PIN(LEDB_port)
#define LEDB_ddrb DDR(LEDB_port)
#endif
#if Out230_Aktywne==1
#define OUT_pin PIN(OUT_port)
#define OUT_ddrb DDR(OUT_port)
#endif
#if dir485_Aktywne==1
#define RS485_pin PIN(RS485_port)
#define RS485_ddrb DDR(RS485_port)
#endif
#if Buzz_Aktywne==1
#define BUZZ_pin PIN(BUZZ_port)
#define BUZZ_ddrb DDR(BUZZ_port)
#endif
//***************************************************************************
//USTAWIANIE STANU WYJSC
#if Buzz_Aktywne==1
#if Buzz_Level==1
#define ON_BUZZ (BUZZ_port |= (1<<BUZZ_bit));
#define OFF_BUZZ (BUZZ_port &= ~(1<<BUZZ_bit));
#elif Buzz_Level==0
#define OFF_BUZZ (BUZZ_port |= (1<<BUZZ_bit));
#define ON_BUZZ (BUZZ_port &= ~(1<<BUZZ_bit));
#endif
#define TOGGLE_BUZZ (BUZZ_port ^= (1<<BUZZ_bit));
#endif
//-----------------------------------------------
#if Out230_Aktywne==1
#if Out230_Level==1
#define ON_OUT OUT_port |= (1<<OUT_bit);
#define OFF_OUT OUT_port &= ~(1<<OUT_bit);
#elif Out230_Level==0
#define OFF_OUT OUT_port |= (1<<OUT_bit);
#define ON_OUT OUT_port &= ~(1<<OUT_bit);
#endif
#define TOGGLE_OUT OUT_port ^= (1<<OUT_bit);
#endif
//-----------------------------------------------
#if dir485_Aktywne==1
#if dir485_Level==1
#define rs485_send RS485_port |= (1<<RS485_bit);
#define rs485_receive RS485_port &= ~(1<<RS485_bit);
#elif dir485_Level==0
#define rs485_receive RS485_port |= (1<<RS485_bit);
#define rs485_send RS485_port &= ~(1<<RS485_bit);
#endif
#define rs485_TOGGLE RS485_port ^= (1<<RS485_bit);
#endif
//-----------------------------------------------
#if Dred_Aktywne==1
#if Dred_Level==1
#define CLR_RED LEDR_port |= (1<<LEDR_bit);
#define SET_RED LEDR_port &= ~(1<<LEDR_bit);
#elif Dred_Level==0
#define SET_RED LEDR_port |= (1<<LEDR_bit);
#define CLR_RED LEDR_port &= ~(1<<LEDR_bit);
#endif
#define TOGGLE_RED LEDR_port ^= (1<<LEDR_bit);
#endif
//-----------------------------------------------
#if Dblue_Aktywne==1
#if Dblue_Level==1
#define CLR_BLUE LEDB_port |= (1<<LEDB_bit);
#define SET_BLUE LEDB_port &= ~(1<<LEDB_bit);
#elif Dblue_Level==0
#define SET_BLUE LEDB_port |= (1<<LEDB_bit);
#define CLR_BLUE LEDB_port &= ~(1<<LEDB_bit);
#endif
#define TOGGLE_BLUE LEDB_port ^= (1<<LEDB_bit);
#endif
//-----------------------------------------------
#if Wyjscie1_Aktywne==1
#if Wyjscie1_Level==1
#define WY1_ON WY1_port |= (1<<WY1_bit);
#define WY1_OFF WY1_port &= ~(1<<WY1_bit);
#elif Wyjscie1_Level==0
#define WY1_OFF WY1_port |= (1<<WY1_bit);
#define WY1_ON WY1_port &= ~(1<<WY1_bit);
#endif
#define WY1_TOGGLE WY1_port ^= (1<<WY1_bit);
#endif
//-----------------------------------------------
#if Wyjscie2_Aktywne==1
#if Wyjscie2_Level==1
#define WY2_ON WY2_port |= (1<<WY2_bit);
#define WY2_OFF WY2_port &= ~(1<<WY2_bit);
#elif Wyjscie2_Level==0
#define WY2_OFF WY2_port |= (1<<WY2_bit);
#define WY2_ON WY2_port &= ~(1<<WY2_bit);
#endif
#define WY2_TOGGLE WY2_port ^= (1<<WY2_bit);
#endif
//-----------------------------------------------
#if Wyjscie3_Aktywne==1
#if Wyjscie3_Level==1
#define WY3_ON WY3_port |= (1<<WY3_bit);
#define WY3_OFF WY3_port &= ~(1<<WY3_bit);
#elif Wyjscie3_Level==0
#define WY3_OFF WY3_port |= (1<<WY3_bit);
#define WY3_ON WY3_port &= ~(1<<WY3_bit);
#endif
#define WY3_TOGGLE WY3_port ^= (1<<WY3_bit);
#endif
//-----------------------------------------------
#if Wyjscie4_Aktywne==1
#if Wyjscie4_Level==1
#define WY4_ON WY4_port |= (1<<WY4_bit);
#define WY4_OFF WY4_port &= ~(1<<WY4_bit);
#elif Wyjscie4_Level==0
#define WY4_OFF WY4_port |= (1<<WY4_bit);
#define WY4_ON WY4_port &= ~(1<<WY4_bit);
#endif
#define WY4_TOGGLE WY4_port ^= (1<<WY4_bit);
#endif
//-----------------------------------------------
#endif
