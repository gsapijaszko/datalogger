#ifndef Wyjscia_libr_conf_H
#define Wyjscia_libr_conf_H
#include "../../MACRO_PORT.h"
//Wyjscia uzywane
#define Wyjscie1_Aktywne		0
#define Wyjscie2_Aktywne		0
#define Wyjscie3_Aktywne		0
#define Wyjscie4_Aktywne		0
#define Dred_Aktywne			1
#define Dblue_Aktywne			1
#define Out230_Aktywne			0
#define dir485_Aktywne			0
#define Buzz_Aktywne			1
//Wyjscia poziomy aktywne
//0 - wyjscie w stanie aktywnym zwarte do masy
//1 - wyjscie w stanie aktywnym odciete od masy
#if Wyjscie1_Aktywne==1
#define Wyjscie1_Level			1
#endif
#if Wyjscie2_Aktywne==1
#define Wyjscie2_Level			1
#endif
#if Wyjscie3_Aktywne==1
#define Wyjscie3_Level			1
#endif
#if Wyjscie4_Aktywne==1
#define Wyjscie4_Level			1
#endif
#if Dred_Aktywne==1
#define Dred_Level				1
#endif
#if Dblue_Aktywne==1
#define Dblue_Level				1
#endif
#if Out230_Aktywne==1
#define Out230_Level			1
#endif
#if dir485_Aktywne==1
#define dir485_Level			1
#endif
#if Buzz_Aktywne==1
#define Buzz_Level				1
#endif
#endif
