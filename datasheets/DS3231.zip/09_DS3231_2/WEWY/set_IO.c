#include "set_IO.h"
void ustaw_IO(void) {
#if UP_AKTYWNY==1
	KLAW_UP_ddrb &= ~(1 << KLAW_UP_bit);
	KLAW_UP_port |= (1 << KLAW_UP_bit);
#endif
#if DOWN_AKTYWNY==1
	KLAW_DOWN_ddrb &= ~(1 << KLAW_DOWN_bit);
	KLAW_DOWN_port |= (1 << KLAW_DOWN_bit);
#endif
#if OK_AKTYWNY==1
	KLAW_OK_ddrb &= ~(1 << KLAW_OK_bit);
	KLAW_OK_port |= (1 << KLAW_OK_bit);
#endif
#if ZEW_AKTYWNY==1
	ZEW_ddrb &= ~(1 << ZEW_bit);
	ZEW_port |= (1 << ZEW_bit);
#endif
#if WE1_AKTYWNY==1
	WE1_ddrb &= ~(1 << WE1_bit);
	WE1_port |= (1 << WE1_bit);
#endif
#if WE2_AKTYWNY==1
	WE2_ddrb &= ~(1 << WE2_bit);
	WE2_port |= (1 << WE2_bit);
#endif
#if WE3_AKTYWNY==1
	WE3_ddrb &= ~(1 << WE3_bit);
	WE3_port |= (1 << WE3_bit);
#endif
#if WE4_AKTYWNY==1
	WE4_ddrb &= ~(1 << WE4_bit);
	WE4_port |= (1 << WE4_bit);
#endif
#if MPX_aktywny==1
	MPX_ddrb &= ~(1 << MPX_bit);
#endif
#if Wyjscie1_Aktywne==1
	WY1_ddrb |= (1 << WY1_bit);
	WY1_port &= ~(1 << WY1_bit);
#endif
#if Wyjscie2_Aktywne==1
	WY2_ddrb |= (1 << WY2_bit);
	WY2_port &= ~(1 << WY2_bit);
#endif
#if Wyjscie3_Aktywne==1
	WY3_ddrb |= (1 << WY3_bit);
	WY3_port &= ~(1 << WY3_bit);
#endif
#if Wyjscie4_Aktywne==1
	WY4_ddrb |= (1 << WY4_bit);
	WY4_port &= ~(1 << WY4_bit);
#endif
#if Dred_Aktywne==1
	LEDR_ddrb |= (1 << LEDR_bit);
	LEDR_port &= ~(1 << LEDR_bit);
#endif
#if Dblue_Aktywne==1
	LEDB_ddrb |= (1 << LEDB_bit);
	LEDB_port &= ~(1 << LEDB_bit);
#endif
#if Out230_Aktywne==1
	OUT_ddrb |= (1 << OUT_bit);
	OUT_port &= ~(1 << OUT_bit);
#endif
#if dir485_Aktywne==1
	RS485_ddrb |= (1 << RS485_bit);
	RS485_port &= ~(1 << RS485_bit);
#endif
#if Buzz_Aktywne==1
	BUZZ_ddrb |= (1 << BUZZ_bit);
	BUZZ_port &= ~(1 << BUZZ_bit);
#endif
}
