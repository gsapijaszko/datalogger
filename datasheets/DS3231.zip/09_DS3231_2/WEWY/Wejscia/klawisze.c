#include "klawisze.h"
#include "klawisze_libr_conf.h"
//Zmienne mapowania klawiszy
volatile uint8_t key_status = 0;	//klawisz wcisniety
volatile uint8_t key_acts = 0;	//klawisz obsluzony
volatile uint8_t key_rises = 0;	//reakcja na zbocza

//Aktualizuje zmienne mapowania klawiszy
//**********************************************************************************
void keyf(uint8_t port, uint8_t pin, uint8_t id,void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise,uint8_t level)
{
	if(!(key_status&(1<<id)) && (!(port&(1<<pin))^(level)))
		{
		key_status |= (1<<id);//przycisk wci�ni�ty
		Ltab[id]=debounce;
		}
		if(!Ltab[id])
		{
		if((!(port&(1<<pin))^(level)))
		key_acts |= (1<<id);//przycisk wci�ni�ty
		}
		if(!(!(port&(1<<pin))^(level)))
		{
			waitus(debounce);
			if(!(!(port&(1<<pin))^(level)))
			key_status &= ~(1<<id);//odznacz w tablicy wci�ni�tych
		}
	if(((key_acts&(1<<id))||(key_status&(1<<id)))&&(!(key_rises&(1<<id))))
		{
		if(!Ltabr[id])
		{
		Ltabr[id]=repeat;
		f();
		key_rises |= (!((1<<id))^(rise));
		}
		}
	if (!(key_status&(1<<id)))
		{
		key_rises &= ~(1<<id);
			key_acts &= ~(1<<id);
		}
	return;
}

