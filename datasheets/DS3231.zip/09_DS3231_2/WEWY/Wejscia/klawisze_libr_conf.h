#ifndef Klawisze_libr_conf_H
#define Klawisze_libr_conf_H
//WYBOR KOMPILOWANYCH PODPROGRAMOW
#define UP_AKTYWNY					1
#define DOWN_AKTYWNY				1
#define OK_AKTYWNY					1
#define WE1_AKTYWNY					0
#define WE2_AKTYWNY					0
#define WE3_AKTYWNY					0
#define WE4_AKTYWNY					0
#define ZEW_AKTYWNY					0
//***************************************************************************
//Opcjonalne makra do uzycia w programie, nie powiazane z funkcjami tej biblioteki
#define pressMacros 1
// 1- reakcja na stan wysoki, 0 reakcja na stan niski
#if UP_AKTYWNY==1
#define 			UP_Level		0
#endif
#if DOWN_AKTYWNY==1
#define 			DOWN_Level		0
#endif
#if OK_AKTYWNY==1
#define 			OK_Level		0
#endif
#if WE1_AKTYWNY==1
#define 			WE1_Level		1
#endif
#if WE2_AKTYWNY==1
#define 			WE2_Level		1
#endif
#if WE3_AKTYWNY==1
#define 			WE3_Level		1
#endif
#if WE4_AKTYWNY==1
#define 			WE4_Level		0
#endif
#if ZEW_AKTYWNY==1
#define 			ZEW_Level		0
#endif
//***************************************************************************
//***************************************************************************
//***************************************************************************
//numery bitow po zmapowaniu klawiszy do zmiennych key_status, key_acts i key_rises
//nie nalezy zmieniac!
#if UP_AKTYWNY==1
#define actUPbit	0
#endif
#if DOWN_AKTYWNY==1
#define actDOWNbit	1
#endif
#if OK_AKTYWNY==1
#define actOKbit	2
#endif
#if WE1_AKTYWNY==1
#define actWE1bit	3
#endif
#if WE2_AKTYWNY==1
#define actWE2bit	4
#endif
#if WE3_AKTYWNY==1
#define actWE3bit	5
#endif
#if WE4_AKTYWNY==1
#define actWE4bit	6
#endif
#if ZEW_AKTYWNY==1
#define actZEWbit	7
#endif
#endif
