#ifndef Klawisze_H
#define Klawisze_H
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <util/delay.h>
#include "klawisze_libr_conf.h"
#include "../../TIMERY/opoznienie.h"
#include "../../MACRO_PORT.h"
#include "../../TIMERY/tajmer2.h"
//***************************************************************************
//DEFINICJA PORTOW WE / WY
#if UP_AKTYWNY==1			//Klawisz UP
#define KLAW_UP_bit 		7
#define KLAW_UP_port 		PORTC
#endif
//*************************
#if DOWN_AKTYWNY==1			//Klawisz DOWN
#define KLAW_DOWN_bit 		6
#define KLAW_DOWN_port 		PORTC
#endif
//*************************
#if OK_AKTYWNY==1			//Klawisz OK
#define KLAW_OK_bit 		7
#define KLAW_OK_port 		PORTA
#endif
//*************************
#if WE1_AKTYWNY==1			//Wejscie 1
#define WE1_bit 			3
#define WE1_port 			PORTA
#endif
//*************************
#if WE2_AKTYWNY==1			//Wejscie 2
#define WE2_bit 			2
#define WE2_port 			PORTA
#endif
//*************************
#if WE3_AKTYWNY==1			//Wejscie 3
#define WE3_bit 			3
#define WE3_port 			PORTD
#endif
//*************************
#if WE4_AKTYWNY==1			//Wejscie 4
#define WE4_bit 			2
#define WE4_port 			PORTD
#endif
//*************************
#if ZEW_AKTYWNY==1			//Wejscie zewnetrzne 230V
#define ZEW_bit 			1
#define ZEW_port 			PORTB
#endif
//***************************************************************************
#if UP_AKTYWNY==1
#define KLAW_UP_ddrb DDR(KLAW_UP_port)
#define KLAW_UP_pin PIN(KLAW_UP_port)
#endif
#if DOWN_AKTYWNY==1
#define KLAW_DOWN_pin PIN(KLAW_DOWN_port)
#define KLAW_DOWN_ddrb DDR(KLAW_DOWN_port)
#endif
#if OK_AKTYWNY==1
#define KLAW_OK_pin PIN(KLAW_OK_port)
#define KLAW_OK_ddrb DDR(KLAW_OK_port)
#endif
#if WE1_AKTYWNY==1
#define WE1_pin PIN(WE1_port)
#define WE1_ddrb DDR(WE1_port)
#endif
#if WE2_AKTYWNY==1
#define WE2_pin PIN(WE2_port)
#define WE2_ddrb DDR(WE2_port)
#endif
#if WE3_AKTYWNY==1
#define WE3_pin PIN(WE3_port)
#define WE3_ddrb DDR(WE3_port)
#endif
#if WE4_AKTYWNY==1
#define WE4_pin PIN(WE4_port)
#define WE4_ddrb DDR(WE4_port)
#endif
#if ZEW_AKTYWNY==1
#define ZEW_pin PIN(ZEW_port)
#define ZEW_ddrb DDR(ZEW_port)
#endif
//***************************************************************************
//ROZPOZNANIE POBUDZEN WEJSC
#if pressMacros==1
#if UP_AKTYWNY==1
#define keyUPpress	 (!(KLAW_UP_pin&(1<<KLAW_UP_bit))^UP_Level)
#endif
#if DOWN_AKTYWNY==1
#define keyDOWNpress (!(KLAW_DOWN_pin&(1<<KLAW_DOWN_bit))^DOWN_Level)
#endif
#if OK_AKTYWNY==1
#define keyOKpress	 (!(KLAW_OK_pin&(1<<KLAW_OK_bit))^OK_Level)
#endif
#if WE1_AKTYWNY==1
#define keyWE1press	 (!(WE1_pin&(1<<WE1_bit))^WE1_Level)
#endif
#if WE2_AKTYWNY==1
#define keyWE2press	 (!(WE2_pin&(1<<WE2_bit))^WE2_Level)
#endif
#if WE3_AKTYWNY==1
#define keyWE3press	 (!(WE3_pin&(1<<WE3_bit))^WE3_Level)
#endif
#if WE4_AKTYWNY==1
#define keyWE4press	 (!(WE4_pin&(1<<WE4_bit))^WE4_Level)
#endif
#if ZEW_AKTYWNY==1
#define keyZEWpress	 (!(ZEW_pin&(1<<ZEW_bit))^ZEW_Level)
#endif
#endif
//***************************************************************************
extern volatile uint8_t key_status; //tu zapisane sa stany wcisnietych klawiszy (bez obrobki!!!)
//***************************************************************************
//sprawdzenie stanu pojedynczego klawisza
//Mapuje klawisze do zmiennej key_status a po stwierdzeniu, �e dany klawisz jest wcisniety
//wpisuje 1 na danym bicie w key_acts, key_acts obslugiwae jest przez funkcje nadrzedna
//void Butt(uint16_t port, uint8_t pin, uint8_t id,uint8_t debounce,uint8_t level);
//Funkcja nadrzedna nad butt()
//analizuje zawartosc key_acts i wywoluje odpowiednia funkcje przekazana podczas wywolania
//Ponadto sprawdza, czy dany klawisz ma byc powtarzany, czy tez jest inicjowany zboczem.
//void keyf(uint8_t port, uint8_t pin, uint8_t id,void (*f)(void),uint8_t debounce,uint8_t rise);
enum Klawisz_zbocze {Normal,Rise};
enum Klawisz_zbocze Key_trig;
//**********************************************************************************
void keyf(uint8_t port, uint8_t pin, uint8_t id,void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise,uint8_t level);
//**********************************************************************************
#if UP_AKTYWNY==1
#define UpZbocze(a)	a?(1<<actUPbit):0
inline void kUP(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise) __attribute__((always_inline));
inline void kUP(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise)
{
	keyf(KLAW_UP_pin, KLAW_UP_bit, actUPbit,*f,debounce,repeat ,UpZbocze(rise),UP_Level);
	return;
}
#endif
//**********************************************************************************
#if DOWN_AKTYWNY==1
#define DownZbocze(a)	a?(1<<actDOWNbit):0
inline void kDOWN(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise) __attribute__((always_inline));
inline void kDOWN(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise)
{
	keyf(KLAW_DOWN_pin, KLAW_DOWN_bit, actDOWNbit,*f,debounce,repeat ,DownZbocze(rise),DOWN_Level);
	return;
}
#endif
//**********************************************************************************
#if OK_AKTYWNY==1
#define OkZbocze(a)	a?(1<<actOKbit):0
inline void kOK(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise) __attribute__((always_inline));
inline void kOK(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise)
{
	keyf(KLAW_OK_pin, KLAW_OK_bit, actOKbit,*f,debounce,repeat ,OkZbocze(rise), OK_Level);
	return;
}
#endif
//**********************************************************************************
#if WE1_AKTYWNY==1
#define We1Zbocze(a)	a?(1<<actWE1bit):0
inline void kWE1(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise) __attribute__((always_inline));
inline void kWE1(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise)
{
	keyf(WE1_pin, WE1_bit, actWE1bit,*f,debounce,repeat ,We1Zbocze(rise), WE1_Level);
	return;
}
#endif
//**********************************************************************************
#if WE2_AKTYWNY==1
#define We2Zbocze(a)	a?(1<<actWE2bit):0
inline void kWE2(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise) __attribute__((always_inline));
inline void kWE2(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise)
{
	keyf(WE2_pin, WE2_bit, actWE2bit,*f,debounce,repeat ,We2Zbocze(rise), WE2_Level);
	return;
}
#endif
//**********************************************************************************
#if WE3_AKTYWNY==1
#define We3Zbocze(a)	a?(1<<actWE3bit):0
inline void kWE3(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise) __attribute__((always_inline));
inline void kWE3(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise)
{
	keyf(WE3_pin, WE3_bit, actWE3bit,*f,debounce,repeat ,We3Zbocze(rise), WE3_Level);
	return;
}
#endif
//**********************************************************************************
#if WE4_AKTYWNY==1
#define We4Zbocze(a)	a?(1<<actWE4bit):0
inline void kWE4(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise) __attribute__((always_inline));
inline void kWE4(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise)
{
	keyf(WE4_pin, WE4_bit, actWE4bit,*f,debounce,repeat ,We4Zbocze(rise), WE4_Level);
	return;
}
#endif
//**********************************************************************************
#if ZEW_AKTYWNY==1
#define ZewZbocze(a)	a?(1<<actZEWbit):0
inline void kZEW(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise) __attribute__((always_inline));
inline void kZEW(void (*f)(void),uint8_t debounce,uint8_t repeat,uint8_t rise)
{
	keyf(ZEW_pin, ZEW_bit, actZEWbit,*f,debounce,repeat ,ZewZbocze(rise), ZEW_Level);
		return;
}
#endif
#endif
