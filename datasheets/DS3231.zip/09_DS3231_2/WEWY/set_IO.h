#ifndef set_IO_H
#define set_IO_H
#include "Wejscia/klawisze.h"
#include "Wyjscia/wyjscia.h"
void ustaw_IO(void);	//konfiguracja portow we/wy
#endif
