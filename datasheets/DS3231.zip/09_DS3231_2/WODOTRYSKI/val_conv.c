/*
 * val_conv.c
 *
 *  Created on: 17-04-2012
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#include "val_conv.h"
char BuforKonwersji[MaxIloscZnakowKonwersji];
char * val_conv( uint16_t val, char *buf, int radix, int dig )
{
 char tmp[ 17 ];
 int i = 0;
if(( radix >= 2 ) && ( radix <= 16 ))
 {
 do
 {
 tmp[ i ] = ( val % radix ) + '0';
 if(tmp[ i ] > '9' ) tmp[ i ] += 7;
 val /= radix;
 i++;
 }while( val );
while(( i < dig ) && ( i < 32 ))
 {
 tmp[ i++ ] = '0';
 }
while( i )
 {
 *buf++ = tmp[ i-1 ];
 i--;
 }
 }
 *buf = 0;
 return buf;
}
