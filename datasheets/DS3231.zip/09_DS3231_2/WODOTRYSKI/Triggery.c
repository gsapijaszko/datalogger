#include "Triggery.h"
uint8_t stan;
void TRIG(bool input,void (*f)(void),uint8_t no,uint8_t rise)
{
	if (input && !(stan & (1<<no)))
	{
		stan|=(1<<no);
		if (rise)
		f();
	}
	if (!input && (stan & (1<<no)))
	{
		stan&=~(1<<no);
		if(!rise)
		f();
	}
return;
}
