#ifndef TRIGGERY_H_
#define TRIGGERY_H_
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
void TRIG(bool input,void (*f)(void),uint8_t no,uint8_t rise);
enum Trig_zbocze {Falling,Rising};
enum Trig_zbocze Trise;
enum Trig_numer {Trig0,Trig1,Trig2,Trig3,Trig4,Trig5,Trig6,Trig7};
enum Trig_numer Tno;
#endif /* TRIGGERY_H_ */
