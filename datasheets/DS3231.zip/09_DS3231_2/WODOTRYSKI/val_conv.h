/*
 * val_conv.h
 *
 *  Created on: 17-04-2012
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 *		kod pochodzi ze strony http://mikrokontrolery.blogspot.com/2011/04/temperatura-wyswietlacz-konwersja.html
 */

#ifndef VAL_CONV_H_
#define VAL_CONV_H_
#include <stdio.h>
#include <stdlib.h>
//******************************************************************
/*
 * Je�eli nie b�dziemy konwertowa� liczb dw�jkowych, to mo�emy zaw�zi� rozmiar naszego bufora
 * wynikowego. Odkomentuj w�asciw� definicj�.
 */
#define	KonwersjaDzisietnaHex
//#define	KonwersjaDzisietnaHexDwojkowa
//******************************************************************
#ifdef	KonwersjaDzisietnaHex
#define MaxIloscZnakowKonwersji	6
#else
#ifdef KonwersjaDzisietnaHexDwojkowa
#define MaxIloscZnakowKonwersji	17
#else
#error Bledna konfiguracja nastaw dla funkcji val_conv!
#endif
#endif
extern char BuforKonwersji[MaxIloscZnakowKonwersji];
enum {Bin=2,Dec=10,Hex=16};
enum {deg0,deg1,deg2,deg3,deg4,deg5,deg6,deg7,deg8,deg9,deg10,deg11,deg12,deg13,deg14,deg15,deg16};
char * val_conv(uint16_t val, char *buf, int radix, int dig );
#endif /* VAL_CONV_H_ */
