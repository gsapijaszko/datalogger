/*
 * NapisyFlash.h
 *
 *  Created on: 20-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef NAPISYFLASH_H_
#define NAPISYFLASH_H_
//------------------------------------------------
#include <avr/pgmspace.h>
//------------------------------------------------
//********************************************************************************
/*
 * W taki oto spos�b umieszczamy w pami�ci flash teksty,
 * jakie b�dziemy wyswietla�.
 */
//const uint8_t powitanie[] PROGMEM="Napis FLASH";
const uint8_t PrzedstawSie1[] PROGMEM="Zegar";
const uint8_t PrzedstawSie2[] PROGMEM="i...";
/*
 * Symbole wykorzystywane przez animacj�.
 */
const uint8_t animacja1[] PROGMEM="|";
const uint8_t animacja2[] PROGMEM="/";
const uint8_t animacja3[] PROGMEM="-";
const uint8_t animacja4[] PROGMEM={126,0};
const uint8_t animacja5[] PROGMEM={127,0};
/*
 * Symbole uzywane przy wyswietlaniu daty / czas
 */
const uint8_t rtc_dwukropek[] PROGMEM=":";
const uint8_t rtc_spacja[] PROGMEM=" ";
const uint8_t rtc_slash[] PROGMEM="-";
const uint8_t Pon[] PROGMEM="Poniedz";
const uint8_t Wto[] PROGMEM="Wtorek";
const uint8_t Sro[] PROGMEM="Sroda";
const uint8_t Czw[] PROGMEM="Czwarte";
const uint8_t Pia[] PROGMEM="Piatek";
const uint8_t Sob[] PROGMEM="Sobota";
const uint8_t Nie[] PROGMEM="Niedzie";
const uint8_t *DniTygodnia[] =
{
		Pon,
		Wto,
		Sro,
		Czw,
		Pia,
		Sob,
		Nie,
};
//------------------------------------------------
#endif /* NAPISYFLASH_H_ */
