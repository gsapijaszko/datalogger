/*
 * Parametry.h
 *
 *  Created on: 21-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef PARAMETRY_H_
#define PARAMETRY_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
//------------------------------------------------
/*
 * W tej strukturze umieszczamy sobie zmienne jakie b�dziemy chcieli
 * zapisywa� w pami�ci EEPROM.
 */
typedef struct  {
	uint8_t Parametr1;
	uint8_t Parametr2;
	uint8_t Parametr3;
	uint8_t Parametr4;
	uint8_t Parametr5;
	uint8_t Parametr6;
	uint8_t Parametr7;
	uint8_t Parametr8;
} Zmienne;
//------------------------------------------------
#endif /* PARAMETRY_H_ */
