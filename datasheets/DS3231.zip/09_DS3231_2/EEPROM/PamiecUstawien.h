/*
 * PamiecUstawien.h
 *
 *  Created on: 21-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef PAMIECUSTAWIEN_H_
#define PAMIECUSTAWIEN_H_
//------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <avr/eeprom.h>
#include "Parametry.h"
//------------------------------------------------
/*
 * Do tych 2 struktur b�dziemy mie� dost�p w dalszej cz�sci programu.
 * Po co 2 zestawy identycznych parametr�w?
 * ZSys - u�ywam podczas normalnej pracy programu.
 * ZPro - u�ywam do zmiany nastaw z poziomu menu.
 * Dzi�ki temu w �atwy spos�b realizuj� mo�liwos� odrzucenia nowych nastaw.
 * Ponadto: gdy wejd� do menu to nie musz� przerywac normalnego wykonywania
 * zadan przetwarzanych "w tle" procesow takich jak np. wyswietlanie
 * komunikatow itp.
 */
extern Zmienne ZSys;
extern Zmienne ZPro;
//------------------------------------------------
/******************************************************************************/
void ReadSettings(void);
void WriteSettings(void);
#endif /* PAMIECUSTAWIEN_H_ */
