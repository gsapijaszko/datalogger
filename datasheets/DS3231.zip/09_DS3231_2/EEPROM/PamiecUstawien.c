/*
 * PamiecUstawien.c
 *
 *  Created on: 21-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
//------------------------------------------------
#include "PamiecUstawien.h"
//------------------------------------------------
Zmienne ZSys_eeprom EEMEM;//ta struktura przechowywana jest w EEPROM
Zmienne ZSys;
Zmienne ZPro;
void ReadSettings(void) {
	eeprom_read_block(&ZSys, &ZSys_eeprom, sizeof(ZSys) );
	ZPro  = ZSys;
}
void WriteSettings(void) {
/*
 * Zamiast eeprom_write_block uzywamy eeprom_update_block.
 * Dzi�ki temu do pami�ci eeprom zapisywane s� wy��cznie zmienne,
 * kt�re uleg�y zmianie - zamiast wszystkich zmiennych.
 * Zmniejsza to czas potrzebny na zapis do eeprom oraz wyd�u�a
 * jego �ywotnos�.
 */
	eeprom_update_block(&ZPro, &ZSys_eeprom, sizeof(ZPro) );
}
