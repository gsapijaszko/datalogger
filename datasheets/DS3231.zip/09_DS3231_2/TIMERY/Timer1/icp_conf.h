#ifndef icp_conf_H_
#define icp_conf_H_
#define	HertzProcess		0	//Przeliczanie na herce
#define	TimeOffsetProcess	0	//Korekcja zegara PCF - niepotrzebna - DS3231 jest wystarczaj�co dok�adny
#endif
