#ifndef icp_H_
#define icp_H_
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/interrupt.h>
#include <util/atomic.h>
#include "icp_conf.h"
struct {
   unsigned int fl1 : 1;
   unsigned int fl2 : 1;
   unsigned int fl3 : 1;
   unsigned int fl4 : 1;
   unsigned int fl5 : 1;
   unsigned int fl6 : 1;
   unsigned int fl7 : 2;
} flag;
#define ICP_CompleteExt flag.fl1
#define KierunekExt flag.fl2
#if TimeOffsetProcess==1
extern volatile uint32_t Okres;
extern uint32_t Offset;
#endif
enum{OffsetIddle=0,OffsetPlus=1,OffsetMinus=-1};
#if TimeOffsetProcess==1
int8_t CheckTimeOffset(void);
uint8_t RTCtune( uint8_t *seconds);
#endif
#if HertzProcess==1
uint16_t ICP_Hertz(void);
#endif
void Timer1Init(void);
#endif
