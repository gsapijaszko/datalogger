#include "icp.h"
#if TimeOffsetProcess==1
volatile uint32_t Okres=0;
uint32_t Offset=0;
#endif
volatile uint16_t ov_counter=0;
uint16_t Actual=0, Previous=0;
#define ICP_CompleteInt flag.fl3
#define KierunekInt flag.fl4
#define ICP_CompleteInt1 flag.fl5
#define FirstCycle flag.fl7
#define ICP_RtcTune flag.fl6
//Licznik przepe�nie� timera
//Dzi�ki niemu mo�liwe jest zarejestrowanie impuls�w o d�ugo�ci wi�kszej ni� 65535us
ISR(TIMER1_OVF_vect)
{
	ov_counter++;
}
//Przerwanie obliczaj�ce okres
ISR(TIMER1_CAPT_vect)
{
            Actual=ICR1;
			//Preskaler 8 - dlatego wynik trzeba podzieli� przez 2
            if(FirstCycle>=2)
            {
#if TimeOffsetProcess==1
			Okres=((((uint32_t)(ov_counter)*0xffff+(uint32_t)Actual)-(uint32_t)Previous)>>1);
#endif
			ICP_CompleteInt=true;//wewnetrzna flaga na potrzeby funkcji CheckTimeOffset
			ICP_CompleteExt=true;//flaga do wykorzystania na zewnatrz (przy PCF np. ��danie odczytu zegara)
			ICP_CompleteInt1=true;//wewnetrzna flaga na potrzeby funkcji CheckTimeOffset
            }
            else
            	FirstCycle++;
            ov_counter=0;
            Previous=Actual;
            ICP_RtcTune=true;
}
#if TimeOffsetProcess==1
/*
Funkcja sprawdzaj�ca dryft czasowy uk�adu PCF.
Po zliczeniu 1 sekundy dryftu funkcja zwraca:
"-1" - je�eli zegar dzia�a za szybko i nale�y go zwolni�
"+1" - je�eli zegar dzia�a zbyt wolno
Gotowa do uzycia funkcja RTCtune przyjmuje jako argument wska�nik na zmienn� przechowuj�c� sekundy
edytuj�c j� w swoim wn�trzu i zwraca true jezeli nalezy dokona� korekty czasu.
U�ycie:
if(RTCtune(&TSys.Sekundy))
{
	zapiszRTC(TSys.Godziny, TSys.Minuty, TSys.Sekundy, TSys.Dzien, TSys.Miesiac, TSys.Rok, TSys.DzienTygodnia);
}
Calosc oparta jest o zdarzenia st�d dzia�a nieblokuj�co.
*/
int8_t CheckTimeOffset(void)
{
	int8_t Zwrot=0;
if(ICP_CompleteInt)
	{
	ICP_CompleteInt=false;
	if(Okres>1000000)
		{
		Offset+=Okres-1000000;
		KierunekInt=true;
		}
	else
		{
		Offset+=1000000-Okres;
		KierunekInt=false;
		}
	if(Offset>=1000000)
		{
		Offset-=1000000;
		if(KierunekInt)
			Zwrot=OffsetPlus;
		else
			Zwrot=OffsetMinus;
		}
KierunekExt=KierunekInt;
}
else
	Zwrot=OffsetIddle;
return Zwrot;
}
uint8_t RTCtune( uint8_t *seconds)
{
	if(ICP_RtcTune)
	{
		ICP_RtcTune=false;
	int8_t Tune=0;
	Tune=CheckTimeOffset();
	if(Tune<0||Tune>0)
	{
		switch((*seconds))
					{
					case 0:
						if(Tune<0)
							(*seconds)=59;
						else
							(*seconds)++;
					break;
					case  59:
						if(Tune>0)
							(*seconds)=0;
						else
							(*seconds)--;
					break;
					default:
						//(*seconds)+=Tune;
						(*seconds)+=Tune;
					break;
					}
		return 1;
	}
	else
			return 0;
	}
	else
		return 0;
}
#endif
#if HertzProcess==1
//Funkcja zwraca warto�� cz�stotliwo�ci w tysi�cach herc�w
uint16_t ICP_Hertz(void)
{
static uint16_t Hertz;
if(ICP_CompleteInt1)
{
Hertz=Okres/1000;
ICP_CompleteInt1=false;
}
return Hertz;
}
#endif
void Timer1Init(void)
{
//Przerwanie InputCapture
//Przerwanie od przepe�nienia timera
TIMSK|=(1<<TOIE1)|(1<<TICIE1);
//W��czona redukcja szum�w
//Reakcja na zbocze narastaj�ce
//Preskaler 8 - dla 16MHz taktowanie timera to 2MHZ
TCCR1B|=(1<<ICNC1)|(1<<ICES1)|(1<<CS11);
//Port ICP ustawiony jako wej�cie bez podci�gania
DDRD &= ~(1 << PD6);
PORTD &= ~(1 << PD6);
FirstCycle=0;
sei();
return;
}
