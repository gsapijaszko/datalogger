#ifndef Opoznienie_H
#define Opoznienie_H
#include <util/delay.h>
#include <avr/wdt.h>
/*
 * Funkcje "opakowuj�ce" standardowe funkcje op�nie� z biblioteki.
 * Czemu opakowanie? Je�eli funkcj� op�niaj�c� wywo�amy z argumentem
 * w postaci zmiennej zamiast jawnie podanej wartoci op�nienia to kompilator
 * "zg�upieje" i wygeneruje baaardzo obszerny kod. Dzi�ki "opakowaniu"
 * niedogodno� ta zostaje usuni�ta.
 */
void waitus(uint8_t x);
void waitms(uint8_t x);
void waitsek(uint8_t x);
#endif
