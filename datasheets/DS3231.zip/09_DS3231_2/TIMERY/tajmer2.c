#include "tajmer2.h"
/*
 * Automatyczne obliczenie nastaw rejestr�w konfiguracyjnych Timera.
 * Podajemy czas w milisekundach a skrypt samodzielnie dobierze
 * niezb�dne nastawy preskalera i rejestru OCR.
 */
//******************************************************************
#define IloscCykliT2		((F_CPU*CzasTykniecMsT2)/1000)
#define PreskalerT2 1
#if IloscCykliT2>255
//#warning musi byc preskaler!
#undef PreskalerT2
#define PreskalerT2 8
	#if (IloscCykliT2/PreskalerT2)>255
	//#warning preskaler 8 za maly
#undef PreskalerT2
#define PreskalerT2 32
	#if (IloscCykliT2/PreskalerT2)>255
	//#warning preskaler 32 za maly
#undef PreskalerT2
#define PreskalerT2 64
		#if (IloscCykliT2/PreskalerT2)>255
		//#warning preskaler 64 za maly
#undef PreskalerT2
#define PreskalerT2 128
			#if (IloscCykliT2/PreskalerT2)>255
			//#warning preskaler 128 za maly
#undef PreskalerT2
#define PreskalerT2 256
				#if (IloscCykliT2/PreskalerT2)>255
				//#warning preskaler 256 za maly
#undef PreskalerT2
#define PreskalerT2 1024
					#if (IloscCykliT2/PreskalerT2)>255
					#error *** Timer2: preskaler 1024 za maly! ***
					#define T2PrescalerErr
					#endif
				#endif
			#endif
		#endif
	#endif
#endif
#endif
//******************************************************************
#ifndef T2PrescalerErr
#define RejestrOcrT2	((IloscCykliT2/PreskalerT2)-1)
#endif
//******************************************************************
void tajmer2(void) {
	/*
	 * Automatyczne wyznaczenie wartosci preskalera.
	 */
#if PreskalerT2==1
	  TCCR2 = _BV(WGM21) |_BV(CS20);
#endif
#if PreskalerT2==8
	  TCCR2 = _BV(WGM21) |_BV(CS21) ;
#endif
#if PreskalerT2==32
	  TCCR2 = _BV(WGM21) |_BV(CS21) |_BV(CS20);
#endif
#if PreskalerT2==64
	  TCCR2 = _BV(WGM21) |_BV(CS22);
#endif
#if PreskalerT2==128
	  TCCR2 = _BV(WGM21) |_BV(CS22) |_BV(CS20);
#endif
#if PreskalerT2==256
	  TCCR2 = _BV(WGM21) |_BV(CS22) |_BV(CS21);
#endif
#if PreskalerT2==1024
	  TCCR2 = _BV(WGM21) |_BV(CS22) |_BV(CS21) |_BV(CS20);
#endif
#ifdef RejestrOcrT2
	  OCR2 = RejestrOcrT2;
#endif
	  /*
	   * Aktywacja przerwania z timera.
	   */
	  TIMSK |= _BV(OCIE2);
}
//******************************************************************
//Pomocnicza zmienna wyzwalajaca tykniecie co 10ms
volatile bool Tick=false;
bool Tick1s;
//Liczniki do obslugi klawiszy
uint8_t Ltab[8];
uint8_t Ltabr[8];
//Liczniki programowe ogolnego przeznaczenia
///////////////////////////////////////////////
uint8_t Licznik_8_1;
uint8_t Licznik_8_2;
uint8_t Licznik_8_3;
uint8_t Licznik_8_4;
uint8_t Licznik_8_5;
uint8_t Licznik_8_6;
uint8_t Licznik_8_7;
uint8_t Licznik_8_8;
uint8_t Licznik_8a_1;
uint8_t Licznik_8a_2;
uint8_t Licznik_8a_3;
uint8_t Licznik_8a_4;
uint8_t Licznik_8a_5;
uint8_t Licznik_8a_6;
uint8_t Licznik_8a_7;
uint8_t Licznik_8a_8;
uint16_t Licznik_16_1;
uint16_t Licznik_16_2;
uint16_t Licznik_16_3;
uint16_t Licznik_16_4;
uint16_t Licznik_16_5;
uint16_t Licznik_16_6;
uint16_t Licznik_16_7;
uint16_t Licznik_16_8;
uint16_t Licznik_16_9;
uint16_t Licznik_16_10;
uint16_t Licznik_16_11;

///////////////////////////////////////////////
uint8_t T_LCDrefresh;
uint16_t T_WDTreset;
uint8_t L_MenuZnak1;
uint8_t L_MenuZnak2;
uint8_t L_wejdzDoMenu;
uint16_t L_autoWyjscieZmenu;
ISR(TIMER2_COMP_vect)
{
	Tick=true;
}

