// timer 2 ustawiony do generowania przerwania co 10 milisekund
#ifndef Timer2_H
#define Timer2_H
#include <util/delay.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
/*
 * Automatyczne obliczenie nastaw rejestr�w konfiguracyjnych Timera.
 * Podajemy czas w milisekundach a skrypt samodzielnie dobierze
 * niezb�dne nastawy preskalera i rejestru OCR.
 */
#define CzasTykniecMsT2	10
///////////////////////////////////////////////
void tajmer2(void);
//Liczniki do obslugi klawiszy
extern uint8_t Ltab[8];
extern uint8_t Ltabr[8];
/*
 * Liczniki programowe ogolnego przeznaczenia.
 * Jest to najprostszy spos�b. Mo�na to rozwi�za� zupe�nie inaczej, ale
 * na chwil� obecn� ten spos�b b�dzie dla nas wystarczaj�cy.
 */
extern uint8_t Licznik_8_1;
extern uint8_t Licznik_8_2;
extern uint8_t Licznik_8_3;
extern uint8_t Licznik_8_4;
extern uint8_t Licznik_8_5;
extern uint8_t Licznik_8_6;
extern uint8_t Licznik_8_7;
extern uint8_t Licznik_8_8;
extern uint8_t Licznik_8a_1;
extern uint8_t Licznik_8a_2;
extern uint8_t Licznik_8a_3;
extern uint8_t Licznik_8a_4;
extern uint8_t Licznik_8a_5;
extern uint8_t Licznik_8a_6;
extern uint8_t Licznik_8a_7;
extern uint8_t Licznik_8a_8;
extern uint16_t Licznik_16_1;
extern uint16_t Licznik_16_2;
extern uint16_t Licznik_16_3;
extern uint16_t Licznik_16_4;
extern uint16_t Licznik_16_5;
extern uint16_t Licznik_16_6;
extern uint16_t Licznik_16_7;
extern uint16_t Licznik_16_8;
extern uint16_t Licznik_16_9;
extern uint16_t Licznik_16_10;
extern uint16_t Licznik_16_11;
uint8_t LS;
//Pomocnicza zmienna wyzwalajaca tykniecie co 10ms
extern volatile bool Tick;
extern bool Tick1s;
extern uint8_t T_LCDrefresh;
extern uint16_t T_WDTreset;

extern uint8_t L_MenuZnak1;
extern uint8_t L_MenuZnak2;
extern uint8_t L_wejdzDoMenu;
extern uint16_t L_autoWyjscieZmenu;
inline void SysTick(void) __attribute__((always_inline));
inline void SysTick(void)
{
if(Tick)
	{
	if(LS)LS--;
	if(!LS)
	{
		LS=100;
		Tick1s=true;
	}
		for(uint8_t i=0;i<8;i++)
		{
			if(Ltab[i])Ltab[i]--;
			if(Ltabr[i])Ltabr[i]--;
		}
///////////////////////////////////////////////
	if(Licznik_8_1)Licznik_8_1--;
	if(Licznik_8_2)Licznik_8_2--;
	if(Licznik_8_3)Licznik_8_3--;
	if(Licznik_8_4)Licznik_8_4--;
	if(Licznik_8_5)Licznik_8_5--;
	if(Licznik_8_6)Licznik_8_6--;
	if(Licznik_8_7)Licznik_8_7--;
	if(Licznik_8_8)Licznik_8_8--;
///////////////////////////////////////////////
	if(Licznik_8a_1)Licznik_8a_1--;
	if(Licznik_8a_2)Licznik_8a_2--;
	if(Licznik_8a_3)Licznik_8a_3--;
	if(Licznik_8a_4)Licznik_8a_4--;
	if(Licznik_8a_5)Licznik_8a_5--;
	if(Licznik_8a_6)Licznik_8a_6--;
	if(Licznik_8a_7)Licznik_8a_7--;
	if(Licznik_8a_8)Licznik_8a_8--;
///////////////////////////////////////////////
	if(Licznik_16_1)Licznik_16_1--;
	if(Licznik_16_2)Licznik_16_2--;
	if(Licznik_16_3)Licznik_16_3--;
	if(Licznik_16_4)Licznik_16_4--;
	if(Licznik_16_5)Licznik_16_5--;
	if(Licznik_16_6)Licznik_16_6--;
	if(Licznik_16_7)Licznik_16_7--;
	if(Licznik_16_8)Licznik_16_8--;
	if(Licznik_16_9)Licznik_16_9--;
	if(Licznik_16_10)Licznik_16_10--;
	if(Licznik_16_11)Licznik_16_11--;
///////////////////////////////////////////////
		if(T_LCDrefresh)T_LCDrefresh--;
		if(T_WDTreset)T_WDTreset--;

		if(L_MenuZnak1)L_MenuZnak1--;
		if(L_MenuZnak2)L_MenuZnak2--;
		if(L_wejdzDoMenu)L_wejdzDoMenu--;
		if(L_autoWyjscieZmenu)L_autoWyjscieZmenu--;
		Tick=false;
	}
}
#endif

