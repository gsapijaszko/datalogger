#include "opoznienie.h"
void waitus(uint8_t x) {
	for(uint8_t a=0;a<x;a++)
			_delay_us(1);
}
void waitms(uint8_t x) {
	for(uint8_t a=0;a<x;a++)
		{
		wdt_reset();
		_delay_ms(1);
		}
}
void waitsek(uint8_t x)
{
	for(uint8_t b=0 ; b<x; b++)
		{
			for(uint8_t a = 0; a < 100; a++)
			{
			waitms(10);
			}
		}
}
