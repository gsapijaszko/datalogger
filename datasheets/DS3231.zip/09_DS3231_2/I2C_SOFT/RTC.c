/*
 * RTC.c
 *
 *  Created on: 29-05-2012
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "RTC.h"
uint8_t yearTemp1,yearTemp2,firstRun;
Czas TPro;
Czas TSys;
void zapiszRTC(uint8_t hours, uint8_t minutes, uint8_t seconds,uint8_t day, uint8_t month, uint8_t year, uint8_t wday)
{
	i2c_buffer[ss] = dec2bcd((seconds));	// sekundy
	i2c_buffer[mm] = dec2bcd((minutes));	// minuty
	i2c_buffer[hh] = dec2bcd((hours));	// godziny
	i2c_buffer[wdaysMonths] = (dec2bcd((wday-1))<<5)|dec2bcd(month);
	i2c_buffer[yearDate] = (((year%4))<<6)|dec2bcd(day);
	TWI_write_buf( PCF8583_ADDR, 0x02, 5, i2c_buffer );
	i2c_buffer[0] = year;
	TWI_write_buf( PCF8583_ADDR, 0x1f, 1, i2c_buffer );
	return;
}
//------------------------------------------------
void odczytajRTC(uint8_t *hours, uint8_t *minutes, uint8_t *seconds,uint8_t *day, uint8_t *month, uint8_t *year, uint8_t *wday)
{
	TWI_read_buf( PCF8583_ADDR, 0x1f, 1, i2c_buffer );
	*year=i2c_buffer[0];
	TWI_read_buf( PCF8583_ADDR, 0x02, 5, i2c_buffer );
	yearTemp2=yearTemp1;
	(*seconds) = bcd2dec( (i2c_buffer[ss] ));
	(*minutes) = bcd2dec( (i2c_buffer[mm] ));
	(*hours) = bcd2dec( (i2c_buffer[hh] ));
	(*day) = bcd2dec( (i2c_buffer[yearDate] )& 0x3F);
	(yearTemp1) = ( i2c_buffer[yearDate]>>6);
	(*month) = bcd2dec( (i2c_buffer[wdaysMonths] )& 0x1F);
	TWI_read_buf( PCF8583_ADDR, 0x1f, 1, i2c_buffer );
	*year=i2c_buffer[0];
/*
 * wyznaczenie dnia tygodnia z wykorzystaniem wzoru Zellera na kalendarz wieczny.
 * Algorytm matematyka Mike'a Keith'a.
 */
	int y,m,d;
		y=2000+(*year);
		m=(*month);	d=(*day);
			(*wday)=((d+=m<3?y--:y-2,23*m/9+(d-1)+4+y/4-y/100+y/400)%7)+1;
if((yearTemp1!=yearTemp2)&&(firstRun))
			{
				i2c_buffer[0]=(*year);
				i2c_buffer[0]++;
				TWI_write_buf( PCF8583_ADDR, 0x1f, 1, i2c_buffer );
			}
			firstRun=1;
	return;
}
