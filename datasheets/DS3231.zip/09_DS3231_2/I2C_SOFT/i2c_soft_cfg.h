/*
 * i2c_soft_cfg.h
 *
 *  Created on: 2010-09-07
 *       Autor: Miros�aw Karda�
 */
#ifndef I2C_SOFT_CFG_H_
#define I2C_SOFT_CFG_H_
//----------------------------------------------
#define PCF8583_ADDRread 	0xA3
#define PCF8583_ADDRwrite	0xA2
#define PCF8583_ADDR		0xA0
//bufor danych RTC
extern uint8_t i2c_buffer[12];
//********************************************************************************
#endif /* I2C_SOFT_CFG_H_ */
