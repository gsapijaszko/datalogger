/*
 * RTC.h
 *
 *  Created on: 29-05-2012
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef RTC_H_
#define RTC_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "i2c_soft.h"
#include "struktury_danych_RTC.h"
//------------------------------------------------
void odczytajRTC(uint8_t *hours, uint8_t *minutes, uint8_t *seconds,uint8_t *day, uint8_t *month, uint8_t *year, uint8_t *wday);
void zapiszRTC(uint8_t hours, uint8_t minutes, uint8_t seconds,uint8_t day, uint8_t month, uint8_t year, uint8_t wday);
//------------------------------------------------
#endif /* RTC_H_ */
