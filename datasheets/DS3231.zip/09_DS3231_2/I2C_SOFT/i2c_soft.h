/*
 * i2c_twi.h
 *
 *  Created on: 2010-09-07
 *       Autor: Miros�aw Karda�
 */

#ifndef I2C_SOFT_H_
#define I2C_SOFT_H_

#define ACK 1
#define NACK 0

#include <util/twi.h>
#include "i2c_soft_cfg.h"
#include "i2c_conversions.h"
#include <util/twi.h>
// Makra upraszczaj�ce dost�p do port�w
// *** PORT
#define yPORT(x) XPORT(x)
#define XPORT(x) (PORT##x)
// *** PIN
#define yPIN(x) XPIN(x)
#define XPIN(x) (PIN##x)
// *** DDR
#define yDDR(x) XDDR(x)
#define XDDR(x) (DDR##x)
// definiujemy sobie dla polepszenia czytelno�ci programu typ wyliczeniowy
// wskazuj�cy nam p�niej na odpowiednie indeksy w tablicy (buforze)
enum {ss, mm, hh, yearDate, wdaysMonths};
/****************************************************************************/
void i2cSetBitrate(uint16_t bitrateKHz);
void TWI_start(void);
void TWI_stop(void);
void TWI_write(uint8_t bajt);
uint8_t TWI_read(uint8_t ack);
void TWI_write_buf( uint8_t SLA, uint8_t adr, uint8_t len, uint8_t *buf );
void TWI_read_buf(uint8_t SLA, uint8_t adr, uint8_t len, uint8_t *buf);
#endif /* I2C_TWI_H_ */
