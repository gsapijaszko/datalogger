/*
 * struktury_danych_RTC.h
 *
 *  Created on: 29-05-2012
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef STRUKTURY_DANYCH_RTC_H_
#define STRUKTURY_DANYCH_RTC_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
//------------------------------------------------
typedef struct  {
	uint8_t Godziny;
	uint8_t Minuty;
	uint8_t Sekundy;
	uint8_t Dzien;
	uint8_t Miesiac;
	uint8_t Rok;
	uint8_t DzienTygodnia;

} Czas;
extern Czas TPro;
extern Czas TSys;
//------------------------------------------------
#endif /* STRUKTURY_DANYCH_RTC_H_ */
