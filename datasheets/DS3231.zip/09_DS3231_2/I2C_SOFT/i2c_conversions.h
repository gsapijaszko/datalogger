/*
 * i2c_conversions.h
 *
 *  Created on: 29-05-2012
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef I2C_CONVERSIONS_H_
#define I2C_CONVERSIONS_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
//------------------------------------------------
// konwersja liczby dziesi�tnej na BCD
uint8_t dec2bcd(uint8_t dec);
// konwersja liczby BCD na dziesi�tn�
uint8_t bcd2dec(uint8_t bcd);
//------------------------------------------------
#endif /* I2C_CONVERSIONS_H_ */
