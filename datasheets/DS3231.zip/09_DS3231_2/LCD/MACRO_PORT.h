#ifndef MACRO_PORT_H
#define MACRO_PORT_H
/*
 * Przydatne makro u�atwiaj�ce obs�ug� pin�w mikrokontrolera
 * W interesuj�cej nas bibliotece umieszczamy definicje:
 *
 * #define nazwa_bit 		3
 * #define nazwa_port 		PORTD
 *
 * A reszt� zrobi za nas kompilator:
 *
 * #define nazwa_pin PIN(nazwa_port)
 * #define nazwa_ddrb DDR(nazwa_port)
 *
 */
#define DDR(x) _SFR_IO8(_SFR_IO_ADDR(x)-1)
#define PIN(x) _SFR_IO8(_SFR_IO_ADDR(x)-2)
#endif
