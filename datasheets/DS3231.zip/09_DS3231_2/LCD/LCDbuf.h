/*
 * LCDbuf.h
 *
 *  Created on: 10-03-2012
 *      Author: Thomaz
 */

#ifndef LCDBUF_H_
#define LCDBUF_H_
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <stdlib.h>
#include "lcd.h"
#include "..\TIMERY\tajmer2.h"
/***************************************************************************************/
//Definicja rozmiarow wyswietlacza
#define Lines	2
#define	Columns	16
#define Refresh 15 	//szybkosc odswiezania obrazu (x10ms)
//Definicja znakow specjalnych
#define Space	32
#define Null	0
/***************************************************************************************/
#if Lines<1
#error Zwieksz liczbe wierszy wyswietlacza!
#endif
#if Lines>4
#error Zmniejsz liczbe wierszy wyswietlacza!
#endif
#if Columns<8
#error Zwieksz liczbe kolumn wyswietlacza!
#endif
#if Columns>40
#error Zmniejsz liczbe kolumn wyswietlacza!
#endif
//Definicja bufor�w wyswietlania
char	LCDbuf[Lines][(Columns + 1)];
//bufor dla funkcji itoa mieszcz�cy liczby 16bit
extern char result[Columns+1];
enum LCDmode {Freeze,Clear};
//ustawienie kursora
void bLCDxy(uint8_t x, uint8_t y);
//czyszczenie RAM
void bLCDcls(void);
//wyswietlanie tekstow z RAM na LCD
void LCDdisplay(uint8_t mode);
//zapis tekstow do pamieci RAM
void bLCDtext(const char *txt);
void bLCDpgmtext(const uint8_t  *FlashLoc);
#endif /* LCDBUF_H_ */
