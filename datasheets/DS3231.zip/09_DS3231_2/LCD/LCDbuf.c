#include "LCDbuf.h"
char result[Columns+1];
typedef uint8_t u8;
typedef uint16_t u16;
u8 Px,Py;
void bLCDxy(uint8_t x, uint8_t y)
{
Px=x;
Py=y;
return;
}
//Czyszczenie zawartosci bufora
void bLCDcls(void)
{
	for(uint8_t y=0;y<(Lines);y++)
		{
		for(uint8_t x=0;x<(Columns);x++)
			{
				LCDbuf[y][x]=Space;
			}
		}
return;
}
//wyswietlanie tekstow z RAM na LCD
void LCDdisplay(uint8_t mode)
{
	if(!T_LCDrefresh)
	{
		uint8_t y=0;
		for(uint8_t x=0;x<(Lines);x++)
		{
			LCDxy(0,x);
			for(y=0;y<(Columns);y++)
			{
				LCDchr(LCDbuf[x][y]);
			}
		}
	}
	if(mode)
		bLCDcls();
	return;
}
//zapis tekstow do pamieci RAM
void bLCDtext(const char *txt) {
	while (*txt&&(Px<Columns))
	{
	LCDbuf[Py-1][Px++]=*txt++;
	}
	return;
}


void bLCDpgmtext(const uint8_t  *FlashLoc) {
	register char znak;
	while ((znak=pgm_read_byte(FlashLoc++))&&(Px<Columns))
		{
		LCDbuf[Py-1][Px++]=znak;
		}
return;
}

