//**********************************
//TextXY(x,y,text)
//**********************************
//wyczy�� wy�w.
//LCDcls(void)
//**********************************
//w��cz wyswietlacz
//a=1 w�
//a=0 wy�
//LCD_ON(int a) 
//**********************************
//wl�czanie kurosra 
//a=1 w�
//a=0 wy�
//LCD_CURSOR(int a) 
//**********************************
//miganie kursora
//a=1 w�
//a=0 wy�
//LCD_BLINK(int a) 
//**********************************
//przesuwanie tekstu
//a=1 w prawo
//a=2 w lewo
//a=0 wy�
//void LCD_SHIFT(int a) 
//**********************************
//ustaw kursor na pozycji 0,0
//LCDhome(void)
//**********************************
//wy�lij tekst z RAM na wy�w.
//LCDtext(char *txt)
//**********************************
//umie�� kursor na pozycji x,y
//LCDxy(char x,char y)
//**********************************
#include "lcd.h"
//******************************************************************************
void LCDresetdata(void) //wyzeruj szyn� danych LCD
{
	CLR_D4;
	CLR_D5;
	CLR_D6;
	CLR_D7;
}
//******************************************************************************
void LCDwrite(char d) //zapis bajtu do LCD
{
	LCDresetdata();
	SET_E;
	if (d & 0x10) {
		SET_D4;
	}
	if (d & 0x20) {
		SET_D5;
	}
	if (d & 0x40) {
		SET_D6;
	}
	if (d & 0x80) {
		SET_D7;
	}
	CLR_E;
	LCDresetdata();
	SET_E;
	if (d & 0x01) {
		SET_D4;
	}
	if (d & 0x02) {
		SET_D5;
	}
	if (d & 0x04) {
		SET_D6;
	}
	if (d & 0x08) {
		SET_D7;
	}
	CLR_E;

#if SZYBKOSC==0
	_delay_us(1);
#warning ****************** Bardzo szybki wyswietlacz - t 1us ******************
#elif SZYBKOSC==1
	_delay_us(10);
#warning ****************** Szybki wyswietlacz - t 10us ******************
#elif SZYBKOSC==2
	_delay_us(250);
	_delay_us(50);
#warning ****************** Sredni wyswietlacz  - t 300us ******************
#elif SZYBKOSC==3
	_delay_ms(1);
#warning ******************  Wolny wyswietlacz  - t 1ms ******************
#elif SZYBKOSC==4
	_delay_ms(3);
#warning ****************** Bardzo wolny wyswietlacz - t 3ms ******************
#else 
#error Nie wybrano szybkosci wyswietlacza!!!
#endif
}

//******************************************************************************
void LCDcmd(char d) //Wy�lij komend� do LCD
{
	CLR_RS;
	LCDwrite(d);
	return;
}
//******************************************************************************
void LCDchr(char d) //Wy�lij 1 znak do LCD
{
	SET_RS;
	LCDwrite(d);
	return;
}
//******************************************************************************
void LCDinit(void) //inicjalizacja LCD
{
	RSDDR |= (1 << RSPIN);
	EDDR |= (1 << EPIN);
	D4DDR |= (1 << D4PIN);
	D5DDR |= (1 << D5PIN);
	D6DDR |= (1 << D6PIN);
	D7DDR |= (1 << D7PIN);
	CLR_RS;
	CLR_E;
	_delay_ms(20);
	CLR_D7;
	CLR_D6;
	SET_D4;
	SET_D5;
	unsigned char i;
	for (i = 0; i < 3; i++) {
		SET_E;
		_delay_us(10);
		CLR_E;
		_delay_ms(5);
	}
	CLR_D4;
	SET_E;
	_delay_us(10);
	CLR_E;
	_delay_ms(5);
	LCDcmd(0x28); //function set - interface=4 bit,line=2,font=5x7
	LCDcmd(ONDISP); //display ctrl - display on
	LCDcmd(0x06); //entry mode set - increment
	LCDcmd(0x01); //clear display
	return;
}
//******************************************************************************
//wyczy�� wy�w.
void LCDcls(void) {
	LCDcmd(CLRDISP);
	return;
}
//******************************************************************************
//w��cz wyswietlacz
//a=1 w�
//a=0 wy�
#if WlWyswietl
void LCD_ON(char a) {
	if (a) {
		LCDcmd(ONDISP);
	} else {
		LCDcmd(OFFDISP);
	}
	return;
}
#endif
//******************************************************************************
//wl�czanie kurosra 
//a=1 w�
//a=0 wy�
#if WlKursora==1
void LCD_CURSOR(char a) {
	if (a) {
		LCDcmd(ONDISP | 0x02);
	} else {
		LCDcmd(ONDISP);
	}
	return;
}
#endif
//******************************************************************************
//miganie kursora
//a=1 w�
//a=0 wy�
#if Miganie==1
void LCD_BLINK(char a) {
	if (a) {
		LCDcmd(ONDISP | 0x01);
	} else {
		LCDcmd(ONDISP);
	}
	return;
}
#endif
//******************************************************************************
//przesuwanie tekstu
//a=1 w prawo
//a=2 w lewo
//a=0 wy�
#if Rollowanie==1
void LCD_SHIFT(char a) {
	if (a == 1) {
		LCDcmd(SHIFT | 0x04);
	} //w prawo
	else if (a == 2) {
		LCDcmd(SHIFT);
	} // w lewo
	else {
		LCDcmd(ONDISP);
	} // wy��czenie przesuwania
	return;
}
#endif
//******************************************************************************
//ustaw kursor na pozycji 0,0
#if CarrReturn==1
void LCDhome(void) {
	LCDcmd(HOMEDISP);
	return;
}
#endif
//******************************************************************************
//wy�lij tekst z RAM na wy�w.
void LCDtext(char *txt) {
	while (*txt) {
		LCDchr(*txt++);
	}
	return;
}
#if ProgTexts==1
void LCDpgmtext(const uint8_t *FlashLoc) {
	register char znak;
	while((znak=pgm_read_byte(FlashLoc++)))
		LCDchr(znak);
return;
}
#endif
//******************************************************************************
//umie�� kursor na pozycji x,y - brak kontroli dla x i y
void LCDxy(char x, char y) {
	unsigned char com = 0x80;
	com |= (x | (y << 6));
	LCDcmd(com);
	return;
}
//******************************************************************************

