#ifndef LCD_H
#define LCD_H
#include "MACRO_PORT.h"
#include <util/delay.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <stdlib.h>
/* Szybkosc zapisu do wyswietlacza:
 SZYBKOSC==0 * Bardzo szybki wyswietlacz - t 1us ****************** 
 SZYBKOSC==1 * Szybki wyswietlacz - t 10us 		****************** 
 SZYBKOSC==2 * Sredni wyswietlacz  - t 300us 	****************** 
 SZYBKOSC==3 * Wolny wyswietlacz  - t 1ms 		****************** 
 SZYBKOSC==4 * Bardzo wolny wyswietlacz - t 3ms 	****************** 
 */
#define SZYBKOSC	2
/*
 * Konfiguracja pin�w wyswietlacza
 */
#define RSPIN 		0
#define RSPORT 		PORTA

#define EPIN  		2
#define EPORT  		PORTA

#define D4PIN 		3
#define D4PORT 		PORTA

#define D5PIN 		4
#define D5PORT 		PORTA

#define D6PIN 		5
#define D6PORT 		PORTA

#define D7PIN 		6
#define D7PORT 		PORTA
/*
 * Konfiguracja biblioteki
 */
#define	Miganie		0	//miganie kursora
#define WlKursora	0	//wlaczenie kursora
#define Rollowanie	0	//przesuwanie tekstu
#define WlWyswietl	0	//mozliwosc wylaczenia wyswietlacza
#define CarrReturn	0	//komenda powrotu kursora
/*
 * Z pozwyzszych nigdy nie korzystam.
 * Za to uzywam opcji wyswietlania z FLASH
 */
#define ProgTexts	0	//uzywamy tekst�w z pamieci FLASH?
//***************************************************************************
/*
 * Makra wyliczaj�ce adresy rejestr�w DDR
 */
#define RSDDR DDR(RSPORT)
#define EDDR DDR(EPORT)
#define D4DDR DDR(D4PORT)
#define D5DDR DDR(D5PORT)
#define D6DDR DDR(D6PORT)
#define D7DDR DDR(D7PORT)
/*
 * Makra umo�liwiaj�ce �atwe sterowanie pinami
 */
#define SET_D4 D4PORT|=(1<<D4PIN);
#define SET_D5 D5PORT|=(1<<D5PIN);
#define SET_D6 D6PORT|=(1<<D6PIN);
#define SET_D7 D7PORT|=(1<<D7PIN);

#define CLR_D4 D4PORT&=~(1<<D4PIN);
#define CLR_D5 D5PORT&=~(1<<D5PIN);
#define CLR_D6 D6PORT&=~(1<<D6PIN);
#define CLR_D7 D7PORT&=~(1<<D7PIN);

#define SET_E EPORT|=(1<<EPIN);
#define CLR_E EPORT&=~(1<<EPIN);

#define SET_RS RSPORT|=(1<<RSPIN);
#define CLR_RS RSPORT&=~(1<<RSPIN);
/*
 * Predefinicja komend steruj�cych wywietlaczem
 */
#define CLRDISP 0x01	//czysc wyswietlacz
#define HOMEDISP 0x02	//kursor na pozycje 0,0
#define	OFFDISP 0x08 	//wylacz ekran
#define ONDISP 0x0c 	//wlacz ekran
#define SHIFT 0x9f 		// przesuwanie kursora
//koniec uproszcze�
//******************************************************************************
void LCDcmd(char d); //Wy�lij komend� do LCD
//******************************************************************************
void LCDchr(char d); //Wy�lij 1 znak do LCD
//******************************************************************************
void LCDinit(void);  //inicjalizacja LCD
//******************************************************************************
void LCDcls(void);	 //wyczy�� wy�w.
//******************************************************************************
//wy�lij tekst z RAM na wy�w.
void LCDtext(char *txt);
//wy�lij tekst z ROM na wy�w.
#if ProgTexts==1
void LCDpgmtext(const uint8_t *FlashLoc);
#endif
//******************************************************************************
//umie�� kursor na pozycji x,y - brak kontroli dla x i y
void LCDxy(char x, char y);
//******************************************************************************
//w��cz wyswietlacz
//a=1 w�
//a=0 wy�
#if WlWyswietl==1
void LCD_ON(char a);
#endif
//******************************************************************************
//wl�czanie kurosra 
//a=1 w�
//a=0 wy�
#if WlKursora==1
void LCD_CURSOR(char a);
#endif
//******************************************************************************
//miganie kursora
//a=1 w�
//a=0 wy�
#if	Miganie==1
void LCD_BLINK(char a);
#endif
//******************************************************************************
//przesuwanie tekstu
//a=1 w prawo
//a=2 w lewo
//a=0 wy�
#if Rollowanie==1
void LCD_SHIFT(char a);
#endif
//******************************************************************************
//ustaw kursor na pozycji 0,0
#if CarrReturn
void LCDhome(void);
#endif
//******************************************************************************
#endif
