/*
 * Menu_napisy.c
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "Menu_napisy.h"
//------------------------------------------------
/*
 * Definiujemy teksty dla poszczeg�lnych pozycji menu.
 */
const unsigned char MN01[] PROGMEM="1.Czas / Data";
	const unsigned char MN01_1[] PROGMEM="1.Czas";
	const unsigned char MN01_2[] PROGMEM="2.Data";

const unsigned char MN02[] PROGMEM="2.Menu 2";
	const unsigned char MN02_1[] PROGMEM="1.subMenu 2/1";
	const unsigned char MN02_2[] PROGMEM="2.subMenu 2/2";
	const unsigned char MN02_3[] PROGMEM="3.subMenu 2/3";

const unsigned char MN00[] PROGMEM="3.Wyjscie";
	const unsigned char MN00_1[] PROGMEM="1.Zapisz&wyjdz";
	const unsigned char MN00_2[] PROGMEM="2.Odrzuc&wyjdz";
	const unsigned char MN00_3[] PROGMEM="3.Nast.fabryczne";
