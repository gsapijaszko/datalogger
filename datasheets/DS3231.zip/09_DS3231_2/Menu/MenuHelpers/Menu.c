/*
 * Menu.c
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "../Menu.h"
#include "../../../WODOTRYSKI/val_conv.h"
#include "../../../TIMERY/tajmer2.h"
#include "../../../WEWY/Wejscia/klawisze.h"
//------------------------------------------------
volatile uint16_t	current_menu;//zmienna ta przechowuje informacj� o aktualnie wybranej pozycji menu
/*
 * Symbole uzywane w menu
 */
const uint8_t editL[] PROGMEM=">";
const uint8_t editR[] PROGMEM="<";
const uint8_t spacja[] PROGMEM=" ";
const uint8_t dwukropek[] PROGMEM=":";
const uint8_t slash[] PROGMEM="/";
/*
 * Informujemy o wejsciu do menu.
 */
const uint8_t wejscieMenu1[] PROGMEM="WCHODZE DO MENU!";
const uint8_t wejscieMenu2[] PROGMEM="TRZYMAJ KLAW. OK";
/*
 * Informujemy o restarcie urz�dzenia
 */
const uint8_t restart1[] PROGMEM="UWAGA!  Trwa";
const uint8_t restart2[] PROGMEM="restart modulu";

/*
 * Zdarzenie generuj�ce przejscie automatu do nast�pnego stanu
 */
volatile unsigned char	menu_event = E_IDDLE;
void point(uint8_t decPoint)
{
	if(decPoint)
		{
		uint8_t str_len=0;
		for(uint8_t i=0;result[i]!=0;i++)
		{
			str_len++;
		}

		if(str_len>decPoint)
			{
			uint8_t i=0;
			do
			{
				result[str_len-i]=result[str_len-1-i];
				i++;
			}while(i<decPoint);
		result[str_len-i]=',';
			}
		}

}
uint16_t changer(unsigned char event,uint16_t min,uint16_t max,uint16_t Val, uint8_t radix, uint8_t dig,uint8_t decPoint,const uint8_t *symL,const uint8_t *symR,uint8_t keyBeh )
{
	bLCDpgmtext(symL);
	switch (event)
			{
				case E_Next:
					if(keyBeh)
						(Val)--;
						break;
				case E_Click:
					(Val)++;
					break;
			}
	if(min<=max)
	{
	if ((Val) < min)
		(Val) = min;
	if ((Val) > max)
		(Val) = max;
	}
	else
	{
		if ((Val) > min)
			(Val) = max;
		if ((Val) < max)
			(Val) = min;
		}
	val_conv(Val, result, radix, dig);
	point(decPoint);
	if(L_MenuZnak2/50)
	{
		for(uint8_t i=0;result[i]!=0;i++)
		{
			result[i]='_';
		}
	}
	bLCDtext(result);
		if(!L_MenuZnak2)
			L_MenuZnak2=75;
	bLCDpgmtext(symR);
			return Val;
}
uint16_t changeAndDisplay(u8 posx,u16 war1,u16 war2,u16 war3,u16 min,u16 max,u8 dpoint,u8 zeros,const uint8_t *sym,u8 actual,u8 noV,u8 LastSym,unsigned char event)
{
		uint16_t wartosci[3]={0,0,0};
		wartosci[0]=war1;
		wartosci[1]=war2;
		wartosci[2]=war3;
		if(actual!=First)
			posx++;
		bLCDxy(posx,2);
		for(uint8_t wartosc=1;wartosc<noV+1;wartosc++)
		{
					if((actual+1)==wartosc)
						wartosci[wartosc-1]=changer(event,min,max,wartosci[wartosc-1],Dec,zeros,dpoint,editL,editR,E_NextRout);
					else{
						val_conv(wartosci[wartosc-1], result, Dec, zeros);
								point(dpoint);
								bLCDtext(result);
					}
					if((noV==wartosc))
					{
						if(LastSym)
						{
							bLCDpgmtext(spacja);
					bLCDpgmtext(sym);
						}
					}
					else
					{
						if((wartosc>actual+1)||(wartosc<actual))
						{
						bLCDpgmtext(spacja);
						}
					bLCDpgmtext(sym);
					}
		}
		return wartosci[actual];
}
/*
 * Wywo�anie naszej funkcji przypisanej do pozycji menu
 */
void call_event_callback_fun(void)
{
void (*call)(unsigned char event);					//wska�nik na wska�nik do funkcji w pami�ci programu
memcpy_P(&call, &menu[current_menu].callback, sizeof(unsigned char (*)(unsigned char)));//ustaw wska�nik na wska�niku wlasciwej funkcji callback
if (call)	//jezeli zadeklarowano funkcj� callback dla zdarzenia to wywolaj j�
call(menu_event);
}
/*
 * Zmiana aktualnej pozycji menu
 */
void change_menu(void)
{
	//przejdz do nastepnego
	volatile unsigned char	previous_menu = 0;
	previous_menu=current_menu;
	current_menu = pgm_read_byte(&menu[current_menu].next_state[menu_event]);	//stanu
	//wywolaj funkcje zwrotna
	if(previous_menu==current_menu)
	{
		call_event_callback_fun();
	}
	//skasuj zdarzenie
	menu_event = E_IDDLE;
}
/*
 * Wyswietlenie aktualnej pozycji menu
 */
void display_menu(void)
{
	bLCDxy(0,1);
		if(L_MenuZnak1>50)
		{
			bLCDtext(" ");
		}
		else
			{
			bLCDtext(">");
			}
	if(!L_MenuZnak1)
		L_MenuZnak1=100;
	for(uint8_t wiersz=0;wiersz<Lines;wiersz++)
	{	unsigned int temp=0;
			temp = pgm_read_word(&menu[current_menu].Line[wiersz]);
			if(temp)
			{
				bLCDxy(1,wiersz+1);
				bLCDpgmtext((void *)temp);
			}
	}
	call_event_callback_fun();
}
/*
 * Podczas przebywania w menu generujemy sobie eventy dla
 * naszego automatu sekwencyjnego.
 */
void up(void)
{
	menu_event=E_Prev;
}
void down(void)
{
	menu_event=E_Next;
}
void ok(void)
{
	menu_event=E_Click;
}
/*
 * Definiujemy funkcje z jakich korzysta� b�dziemy w menu.
 */
void menu_(void)
{
//wejscie do menu
if ((!wejdzDoMenu)&&(!L_wejdzDoMenu)&&(keyOKpress))
	{
	L_wejdzDoMenu=100;
	wejdzDoMenu=true;
	}
//opuszczenie menu
if (inMenu && (!L_autoWyjscieZmenu || opuscMenu))
	{
	inMenu=!inMenu;
	zrestartujSPA=true;
	current_menu=0;
	}
}
// Wejscie do menu sterownika
inline void wejdz_do_menu(void) __attribute__((always_inline));
inline void wejdz_do_menu(void)
{
	if (wejdzDoMenu&&!L_wejdzDoMenu)
			{
			wejdzDoMenu=false;
			if (keyOKpress)
			{
			inMenu=!inMenu;
			ReadSettings();
			UpdateLicznikAutowyjsciaMenu=true;
			}
			}

		if (wejdzDoMenu)
				{
/*
 * Tutaj mo�emy wyswietlic informacj� o tym, �e wchodzimy do menu.
 */
			WejscieDoMenu=true;
			bLCDxy(0,1);
			bLCDpgmtext(wejscieMenu1);
			bLCDxy(0,2);
			bLCDpgmtext(wejscieMenu2);
				}

	return;
}


void MenuProcess(void)
{
	if(UpdateLicznikAutowyjsciaMenu)
			{
			UpdateLicznikAutowyjsciaMenu=false;
			if(inMenu)
			L_autoWyjscieZmenu=6100;
			}
	if(inMenu)
	{
	kUP(*up,25,25,Normal);
	kDOWN(*down,25,pgm_read_byte(&menu[current_menu].KeyNextRepeat),Normal);
	if(!WejscieDoMenu)
	{kOK(*ok,25,pgm_read_byte(&menu[current_menu].KeyClickRepeat),Normal);}

	if (menu_event&&(!WejscieDoMenu))
		{
			change_menu();
			UpdateLicznikAutowyjsciaMenu=true;
			MenuWlaczBuzzer=true;
		}
	if (!keyOKpress)
		{
			WejscieDoMenu=false;
		}
	display_menu();
	if(!L_autoWyjscieZmenu)
	{
		menu_();
	}
	}
	else
	{
		L_autoWyjscieZmenu=0;

		if (keyOKpress&&(!L_autoWyjscieZmenu)&&(!wejdzDoMenu))
			{menu_();}
		wejdz_do_menu();
	}
	wyswietlaniePozaMenu=(!inMenu&&!wejdzDoMenu);
}
void ProceduraRestartu(void)
{
	if(zrestartujSPA)
		{
			//OFF_BUZZ;
			bLCDxy(2,1);
			bLCDpgmtext(restart1);
			bLCDxy(1,2);
			bLCDpgmtext(restart2);
			wdt_enable(WDTO_2S);
			T_LCDrefresh=0;
			LCDdisplay(Freeze);
			while(1)
			{
				;
			}
		}
}
