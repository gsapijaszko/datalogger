/*
 * Menu_Flags.h
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef MENU_FLAGS_H_
#define MENU_FLAGS_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
//------------------------------------------------
/*
 * Te flagi bior� bezposredni udzia� w obs�udze menu.
 */
struct {
   unsigned int f1 : 1;
   unsigned int f2 : 1;
   unsigned int f3 : 1;
   unsigned int f4 : 1;
   unsigned int f5 : 1;
   unsigned int f6 : 1;
   unsigned int f7 : 1;
   unsigned int f8 : 1;
} MenuFlags;
#define	zrestartujSPA					MenuFlags.f1
#define	inMenu							MenuFlags.f2
#define	opuscMenu						MenuFlags.f3
#define	wejdzDoMenu						MenuFlags.f4
#define	UpdateLicznikAutowyjsciaMenu 	MenuFlags.f5
#define	wyswietlaniePozaMenu		 	MenuFlags.f6
#define	MenuWlaczBuzzer				 	MenuFlags.f7
#define	WejscieDoMenu				 	MenuFlags.f8
//------------------------------------------------
#endif /* MENU_FLAGS_H_ */
