/*
 * Menu_DefinicjaFunkcji.c
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "../Menu_strukturaPozycji.h"
#include "../Menu.h"
//------------------------------------------------
//wyjdz z menu i zapamietaj wprowadzone dane
void opuscZapiszMenu(unsigned char event)
{//current_menu=0;
	WriteSettings();
	opuscMenu=true;
	menu_();
	return;
}
//wyjdz z menu i odrzuc zmiany
void opuscBezZapisuMenu(unsigned char event)
{//current_menu=0;
	opuscMenu=true;
	menu_();
	return;
}
