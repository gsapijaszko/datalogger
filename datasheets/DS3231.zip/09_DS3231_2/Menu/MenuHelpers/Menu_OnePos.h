/*
 * Menu_OnePos.h
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef MENU_ONEPOS_H_
#define MENU_ONEPOS_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "../../../LCD/LCDbuf.h"
//------------------------------------------------
/*
 * Definiujemy struktur� opisuj�c� pojedyncz� pozycj�
 * naszego menu.
 */
typedef struct
{
	uint8_t next_state[4];					//przej�cia do nast�pnych stan�w
	uint8_t KeyClickRepeat;					//cz�stotliwosc powt�rze� - klawisz OK
	uint8_t KeyNextRepeat;					//cz�stotliwos� powt�rze� - klawisz Down
	void (*callback)(unsigned char event);	//wska�nik na funkcj� zwrotn�
	const unsigned char* Line[Lines];		//tekst dla 1. linii LCD
} menu_item;
//------------------------------------------------
#endif /* MENU_ONEPOS_H_ */
