/*
 * Menu_BehaviorEnums.h
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef MENU_BEHAVIORENUMS_H_
#define MENU_BEHAVIORENUMS_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
//------------------------------------------------
/*
 * Numer aktualnie edytowanej wartosci dla funkcji changeAndDisplay
 */
enum {First,Second,Third};
/*
 * Chcemy, aby niekt�re pozycje menu by�y przewijane szybciej
 * (np. zmiana wartosci zmiennych) a inne wolniej - nawigacja.
 * U�yjemy typu wyliczeniowego.
 */
enum{fastRep=15,slowRep=35};

/*
 * Definiujemy zachowanie pozycji menu:
 * - edycja wartosci
 * - prze��czanie do nast�pnej pozycji menu
 */
enum {E_NextRout,E_NextEdit};
/*
 * W funkcjach changer oraz changeAndDisplay mo�emy sobie zdefiniowa� z iloma miejscami po przecinku ma by�
 * prezentowana nasza wartos�.
 */
enum {noPoint,Point1,Point2,Point3};
//------------------------------------------------
#endif /* MENU_BEHAVIORENUMS_H_ */
