/*
 * Menu_DefinicjaFunkcji.h
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef MENU_DEFINICJAFUNKCJI_H_
#define MENU_DEFINICJAFUNKCJI_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
//------------------------------------------------
/*
 * Tutaj umiecimy funkcje, kt�re b�d� zmienia�y parametry z poziomu menu.
 * Funkcje te tutaj jedynie deklarujemy. Ich definicje umiecimy w pliku main.c
 * Oczywicie nie jest to spos�b do ko�ca elegancki - a� si� prosi tutaj u�ycie mechanizmu
 * rejestrowania i obs�ugi funkcji callback. Ale na t� chwil� rezygnujemy z takiego rozwi�zania.
 */
void zmienParametr1(unsigned char event);
void zmienParametr2(unsigned char event);
void zmienParametr3(unsigned char event);
void zmienParametr4(unsigned char event);
void zmienParametr5(unsigned char event);
//------------------------------------------------
/*
 * Funkcje sta�e dla ka�dego programu: opuszczanie menu
 */
void opuscZapiszMenu(unsigned char event);
void opuscBezZapisuMenu(unsigned char event);
void parametryDomyslne(unsigned char event);
//------------------------------------------------
#endif /* MENU_DEFINICJAFUNKCJI_H_ */
