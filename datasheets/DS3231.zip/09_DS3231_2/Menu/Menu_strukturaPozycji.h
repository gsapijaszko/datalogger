/*
 * Menu_strukturaPozycji.h
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef MENU_STRUKTURA_POZYCJI_H_
#define MENU_STRUKTURA_POZYCJI_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "MenuHelpers/Menu_BehaviorEnums.h"
#include "Menu_napisy.h"
#include "MenuHelpers/Menu_OnePos.h"
#include "Menu_DefinicjaFunkcji.h"
#include "MenuHelpers/Menu_Flags.h"
#include "../../EEPROM/PamiecUstawien.h"
//------------------------------------------------
/*
 * Przy pomocy typu wyliczeniowego generujemy opis stan�w automatu
 * obs�uguj�cego menu.
 */
/*
 * UWAGA!!!
 * Najni�szy poziom submenu odpowiada bezposrednio za wywo�ywanie
 * funkcji s�u��cej do edycji wartosci.
 */
enum {//pozaMenu,
	Menu1,//tu wyswietlamy
		SubMenu1_1,//tu wyswietlamy
			SubMenu1_1_1,//tu edytujemy
			SubMenu1_1_2,//tu edytujemy
		SubMenu1_2,//tu wyswietlamy
			SubMenu1_2_1,//tu edytujemy
			SubMenu1_2_2,//tu edytujemy
			SubMenu1_2_3,//tu edytujemy
//-------------------------------------------
	Menu2,
		SubMenu2_1,
			SubMenu2_1_1,
		SubMenu2_2,
			SubMenu2_2_1,
		SubMenu2_3,
			SubMenu2_3_1,
//-------------------------------------------
	Menu5,
		SubMenu5_1,
			SubMenu5_1_1,
		SubMenu5_2,
			SubMenu5_2_1,
		SubMenu5_3,
			SubMenu5_3_1,
};

/*
 * Teraz sk�adamy sobie tabel� przejs� pomi�dzy pozycjami w naszym menu.
 */
extern const menu_item menu[];
//------------------------------------------------
#endif /* MENU_STRUKTURA_H_ */
