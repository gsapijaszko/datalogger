/*
 * Menu_strukturaPozycji.c
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "Menu_strukturaPozycji.h"
//------------------------------------------------
const menu_item menu[] PROGMEM= {
	// Iddle, Prev, Click, Next
	//{{ pozaMenu, pozaMenu, pozaMenu, Menu1},slowRep, NULL,	{MN_iddle,NULL}},			//poza menu
/*********************************************************************************/
	{{ Menu1, Menu5, SubMenu1_1, Menu2},slowRep,slowRep, NULL, 	{MN01,MN02}},
// Nastawy 1
		{{ SubMenu1_1, Menu1, SubMenu1_1_1, SubMenu1_2},slowRep,slowRep, NULL, 	{MN01_1,MN01_2}},
			{{ SubMenu1_1_1, SubMenu1_1, SubMenu1_1_1, SubMenu1_1_2},fastRep,slowRep, zmienParametr1, 	{MN01_1,NULL}},
			{{ SubMenu1_1_2, SubMenu1_1, SubMenu1_1_2, SubMenu1_1_1},fastRep,slowRep, zmienParametr2, 	{MN01_1,NULL}},
		{{ SubMenu1_2, Menu1, SubMenu1_2_1, SubMenu1_1},slowRep,slowRep, NULL, 	{MN01_2,MN01_1}},
			{{ SubMenu1_2_1, SubMenu1_2, SubMenu1_2_1, SubMenu1_2_2},fastRep,slowRep, zmienParametr3, 	{MN01_2,NULL}},
			{{ SubMenu1_2_2, SubMenu1_2, SubMenu1_2_2, SubMenu1_2_3},fastRep,slowRep, zmienParametr4, 	{MN01_2,NULL}},
			{{ SubMenu1_2_3, SubMenu1_2, SubMenu1_2_3, SubMenu1_2_1},fastRep,slowRep, zmienParametr5, 	{MN01_2,NULL}},
/*********************************************************************************/
// Iddle, Prev, Click, Next
	{{ Menu2, Menu1, SubMenu2_1, Menu5},slowRep,slowRep, NULL, 	{MN02,MN00}},
// Nastawy 2
		{{ SubMenu2_1, Menu2, SubMenu2_1_1, SubMenu2_2},slowRep,slowRep, NULL, 	{MN02_1,MN02_2}},
			{{ SubMenu2_1_1, SubMenu2_1, SubMenu2_1_1, SubMenu2_1_1},slowRep,slowRep, NULL, 	{MN02_1,NULL}},
		{{ SubMenu2_2, Menu2, SubMenu2_2_1, SubMenu2_3},slowRep,slowRep, NULL, 	{MN02_2,MN02_3}},
			{{ SubMenu2_2_1, SubMenu2_2, SubMenu2_2_1, SubMenu2_2_1},slowRep,slowRep, NULL, 	{MN02_2,NULL}},
		{{ SubMenu2_3, Menu2, SubMenu2_3_1, SubMenu2_1},slowRep,slowRep, NULL, 	{MN02_3,MN02_1}},
			{{ SubMenu2_3_1, SubMenu2_3, SubMenu2_3_1, SubMenu2_3_1},slowRep,slowRep, NULL, 	{MN02_3,NULL}},
// Iddle, Prev, Click, Next
/*********************************************************************************/
	{{ Menu5, Menu2, SubMenu5_1, Menu1},slowRep,slowRep, NULL, 	{MN00,MN01}},						//5.Wyjscie
	//5.Wyjscie
		// Iddle, 		Prev, Click, 		Next
		{{ SubMenu5_1, Menu5, SubMenu5_1_1, SubMenu5_2},slowRep,slowRep, NULL, 	{MN00_1,MN00_2}},
			{{ SubMenu5_1_1, SubMenu5_1_1, SubMenu5_1_1, SubMenu5_2_1},slowRep,slowRep, opuscZapiszMenu, 	{NULL,NULL}},						//Data
		{{ SubMenu5_2, Menu5, SubMenu5_2_1, SubMenu5_3},slowRep,slowRep, NULL, 	{MN00_2,MN00_3}},
			{{ SubMenu5_2_1, SubMenu5_2_1, SubMenu5_2_1, SubMenu5_2_1},slowRep,slowRep, opuscBezZapisuMenu, 	{NULL,NULL}},
		{{ SubMenu5_3, Menu5, SubMenu5_3_1, SubMenu5_1},slowRep,slowRep, NULL, 	{MN00_3,MN00_1}},
			{{ SubMenu5_3_1, SubMenu5_3_1, SubMenu5_3_1, SubMenu5_3_1},slowRep,slowRep, parametryDomyslne, 	{NULL,NULL}},
/*********************************************************************************/
	};
