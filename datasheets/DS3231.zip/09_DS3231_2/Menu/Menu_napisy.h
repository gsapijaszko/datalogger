/*
 * Menu_napisy.h
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef MENU_NAPISY_H_
#define MENU_NAPISY_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include <avr/pgmspace.h>
//------------------------------------------------
/*
 * Definiujemy teksty dla poszczeg�lnych pozycji menu.
 */
extern const unsigned char MN01[];
	extern const unsigned char MN01_1[];
	extern const unsigned char MN01_2[];

extern const unsigned char MN02[];
	extern const unsigned char MN02_1[];
	extern const unsigned char MN02_2[];
	extern const unsigned char MN02_3[];

extern const unsigned char MN00[];
	extern const unsigned char MN00_1[];
	extern const unsigned char MN00_2[];
	extern const unsigned char MN00_3[];
//------------------------------------------------
#endif /* MENU_NAPISY_H_ */
