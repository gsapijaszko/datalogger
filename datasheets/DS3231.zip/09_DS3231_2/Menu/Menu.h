/*
 * Menu.h
 *
 *  Created on: 22-01-2013
 *      Author: Tomasz Sklenarski
 *		e-mail: wykonam@biznespoczta.pl
 *		http://stsystem.elektroda.pl
 */
#ifndef MENU_H_
#define MENU_H_
//------------------------------------------------
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/wdt.h>
#include "../../LCD/LCDbuf.h"
#include "Menu_strukturaPozycji.h"
typedef uint8_t 	u8;
typedef uint16_t 	u16;
//------------------------------------------------
/*
 * Definiujemy kody zfarze� dla automatu.
 */
#define E_IDDLE		0
#define E_Prev 		1
#define E_Click 	2
#define E_Next		3
/*
 * Symbole wykorzystywane podczas wyswietlania wartosci
 */
extern const uint8_t editL[];
extern const uint8_t editR[];
extern const uint8_t dwukropek[];
extern const uint8_t slash[];
extern volatile unsigned char	menu_event;//aktualne zdarzenie w menu
extern volatile uint16_t	current_menu;//zmienna ta przechowuje informacj� o aktualnie wybranej pozycji menu
//------------------------------------------------
//Funkcja zmiany pojedynczej wartosci
uint16_t changer(unsigned char event,uint16_t min,uint16_t max,uint16_t Val, uint8_t radix, uint8_t dig,uint8_t decPoint,const uint8_t *symL,const uint8_t *symR,uint8_t keyBeh );
//Funkcja zmiany 2 lub 3 wartosci poprzez prze��czanie si� pomi�dzy nimi.
uint16_t changeAndDisplay(u8 posx,u16 war1,u16 war2,u16 war3,u16 min,u16 max,u8 dpoint,u8 zeros,const uint8_t *sym,u8 actual,u8 noV,u8 LastSym,unsigned char event);
/*
 * Powy�sze funkcje umo�liwiaj� formatowanie:
 * - liczby zer wiod�cych
 * - liczby miejsc po przecinku dla danej wartosci
 * - zakres�w min i max dla danej wartosci
 * - otaczanie aktualnie edytowanej wartosci zdefiniowanymi symbolami (u mnie >var<)
 * - miganie aktualnie edytowanej wartosci
 */
void MenuProcess(void);//obs�uga menu
void menu_(void);
void ProceduraRestartu(void);//restart sterownika
//------------------------------------------------
#endif /* MENU_H_ */
