#define F_CPU 16000000L
#include	"main.h"

// TWI begin
#include "TWI_Master.h"
unsigned char messageBuf[8];
static unsigned char TWI_buf[ TWI_BUFFER_SIZE ];    // Transceiver buffer
static unsigned char TWI_msgSize;                   // Number of bytes to be transmitted.
static unsigned char TWI_state = TWI_NO_STATE;      // State byte. Default set to TWI_NO_STATE.
union TWI_statusReg TWI_statusReg = {0};            // TWI_statusReg is defined in TWI_Master.h
// TWI end

typedef union  {
	uint8_t bytes[7];
	struct  
	{
	uint8_t Sekundy;
	uint8_t Minuty;
	uint8_t Godziny;
	uint8_t DzienTygodnia;
	uint8_t Dzien;
	uint8_t Miesiac;
	uint8_t Rok;
	};
} Czas;
Czas TPro;
Czas TSys;

#define DS3231_ADDR 0xD0

void DS3231_init( void );
uint8_t dec2bcd(uint8_t dec);
uint8_t bcd2dec(uint8_t bcd);
void DS3231_get_datetime( Czas * dt );
void DS3231_set_time( uint8_t hh, uint8_t mm, uint8_t ss );
void DS3231_set_date( uint8_t year, uint8_t month, uint8_t day, uint8_t dayofweek );

void DS3231_init( void ) {
	messageBuf[0] = DS3231_ADDR;
	messageBuf[1] = 0x0e;															// adres rejestru kontrolnego
	messageBuf[2] = 0x0;															// warto�� do zapisania
	TWI_Start_Transceiver_With_Data( messageBuf, 3 );
}

void DS3231_get_datetime( Czas * dt ) {
	messageBuf[0] = DS3231_ADDR;
	messageBuf[1] = 0;
	TWI_Start_Transceiver_With_Data(messageBuf, 2);
	messageBuf[0] = DS3231_ADDR+1;
	TWI_Start_Transceiver_With_Data(messageBuf, 8);
	while ( TWI_Transceiver_Busy() );             // Wait until TWI is ready for next transmission.
	int i;
	for( i=0; i<7; i++ ) dt->bytes[i] = bcd2dec( TWI_buf[i+1] );
}
void DS3231_set_time( uint8_t hh, uint8_t mm, uint8_t ss ) {
	messageBuf[0] = DS3231_ADDR;
	messageBuf[1] = 0;
	messageBuf[2] = dec2bcd(ss);
	messageBuf[3] = dec2bcd(mm);
	messageBuf[4] = dec2bcd(hh);
	TWI_Start_Transceiver_With_Data(messageBuf, 5);
}

void DS3231_set_date( uint8_t year, uint8_t month, uint8_t day, uint8_t dayofweek ) {
	messageBuf[0] = DS3231_ADDR;
	messageBuf[1] = 0x03;
	messageBuf[2] = dayofweek;
	messageBuf[3] = dec2bcd(day);
	messageBuf[4] = dec2bcd(month);
	messageBuf[5] = dec2bcd(year);
	TWI_Start_Transceiver_With_Data(messageBuf, 6);
}
// konwersja liczby dziesi�tnej na BCD
uint8_t dec2bcd(uint8_t dec) {
	return ((dec / 10)<<4) | (dec % 10);
}
// konwersja liczby BCD na dziesi�tn�
uint8_t bcd2dec(uint8_t bcd) {
	return ((((bcd) >> 4) & 0x0F) * 10) + ((bcd) & 0x0F);
}

//********************************************************************************
/*
 * Tutaj umie�cimy funkcje, kt�re b�d� zmienia�y parametry z poziomu menu.
 */
void secDisp(void)
{
	bLCDxy(10,2);
	val_conv(TSys.Sekundy, result, 10, 2);
	bLCDtext(":");
	bLCDtext(result);
	if(menu_event==E_Click)
		F_AktualizujRTC=true;
}
void zmienParametr1(unsigned char event)
{
	secDisp();
	TPro.Godziny=changeAndDisplay(3,TPro.Godziny,TPro.Minuty,0,23,0,noPoint,deg2,rtc_dwukropek,First,2,0, menu_event);
	return;
}
void zmienParametr2(unsigned char event)
{
	secDisp();
	TPro.Minuty=changeAndDisplay(3,TPro.Godziny,TPro.Minuty,0,59,0,noPoint,deg2,rtc_dwukropek,Second,2,0, menu_event);
	return;
}
void zmienParametr3(unsigned char event)
{
	TPro.Dzien=changeAndDisplay(0,TPro.Dzien,TPro.Miesiac,TPro.Rok,31,1,noPoint,deg2,rtc_slash,First,3,0, menu_event);
	bLCDxy(13,2);
	bLCDpgmtext(DniTygodnia[TSys.DzienTygodnia-1]);
	F_AktualizujRTC=true;
	return;
}
void zmienParametr4(unsigned char event)
{
	TPro.Miesiac=changeAndDisplay(0,TPro.Dzien,TPro.Miesiac,TPro.Rok,12,1,noPoint,deg2,rtc_slash,Second,3,0, menu_event);
	bLCDxy(13,2);
	bLCDpgmtext(DniTygodnia[TSys.DzienTygodnia-1]);
	F_AktualizujRTC=true;
	return;
}
void zmienParametr5(unsigned char event)
{
	TPro.Rok=changeAndDisplay(0,TPro.Dzien,TPro.Miesiac,TPro.Rok,42,14,noPoint,deg2,rtc_slash,Third,3,0, menu_event);
	bLCDxy(13,2);
	bLCDpgmtext(DniTygodnia[TSys.DzienTygodnia-1]);
	F_AktualizujRTC=true;
	return;
}

//********************************************************************************
//wprowad� parametry domy�lne i opu�� menu
void parametryDomyslne(unsigned char event)
{
	/*
	 * Tutaj wklepujemy nasze warto�ci parametr�w domy�lnych.
	 */
	opuscZapiszMenu(1);
}
//********************************************************************************
/*
 * Aktualizacja zegara RTC
 */

void RTCtask(void)
{
	if(ICP_CompleteExt)
	{
		if(F_AktualizujRTC)
		{
			DS3231_set_time( TPro.Godziny, TPro.Minuty, 0);
			DS3231_set_date( TPro.Rok, TPro.Miesiac, TPro.Dzien, TPro.DzienTygodnia);
			F_AktualizujRTC = false;
		}
		DS3231_get_datetime( &TSys );
		TPro=TSys;
	ICP_CompleteExt=false;
	}
	return;
}
//********************************************************************************
inline void initPeripherals(void) __attribute__((always_inline));
inline void initPeripherals(void)
{
wdt_enable(WDTO_2S);	//uruchamiamy watchdog z czasem 2s
LCDinit();				//inicjalizujemy wy�wietlacz
LCDcls();				//czy�cimy wyswietlacz
bLCDcls();				//czy�cimy bufor obrazu
ustaw_IO();
// szybko�� TWI ustawiona na sztywno na 100 kHz (przy zegarze procesora 16MHz)
TWBR = TWI_TWBR;                                  // Set bit rate register (Baudrate).
DS3231_init();
/*
 * Po zainicjalizowaniu wy�wietlacza musimy da� mu chwil� na "przetrawienie"
 * nades�anych komend. St�d musimy wstawi� op�nienie kilku ms po inicjalizacji.
 * Mimo wszystko to pryszcz w por�wnaniu z korzy�ciami jakie zyskujemy
 * korzystaj�c z opisywanego w tym przyk�adzie sposobu wy�wietlania.
 */
waitms(25);
tajmer2();
Timer1Init();
sei();
return;
}
//********************************************************************************
enum {ZegarKrotki,ZegarDlugi};
void separator(uint8_t symbol)
{
	if(symbol)
		bLCDpgmtext(rtc_slash);
	else
		bLCDpgmtext(rtc_dwukropek);
	return;
}
void wyswietl_czas(char hours, char minutes, char seconds, u8 TimeFormat,u8 sym)
{
	if(TimeFormat)
	{
		val_conv((hours), result, 10, 2);
		bLCDtext(result);
		separator(sym);
	}
	val_conv((minutes), result, 10, 2);
	bLCDtext(result);
	separator(sym);
	val_conv((seconds), result, 10, 2);
	bLCDtext(result);
	return;
}
//********************************************************************************
inline void wyswietlanieNaLCD(void) __attribute__((always_inline));
inline void wyswietlanieNaLCD(void)
{
	bLCDxy(0,1);
	wyswietl_czas(TSys.Godziny,TSys.Minuty,TSys.Sekundy,ZegarDlugi,0);
	bLCDxy(0,2);
	bLCDpgmtext(DniTygodnia[TSys.DzienTygodnia-1]);
	bLCDxy(8,2);
	wyswietl_czas(TSys.Dzien,TSys.Miesiac,TSys.Rok,ZegarDlugi,1);
	return;
}
//********************************************************************************
inline void sterowanieWyjsc(void) __attribute__((always_inline));
inline void sterowanieWyjsc(void)
{
}

//********************************************************************************
/*
 * Obs�uga buzzera
 */
inline void buzzer(void) __attribute__((always_inline));
inline void buzzer(void)
{
	if(L_buzz)
		{ON_BUZZ;}
	else
		{OFF_BUZZ;}
	return;
}
//********************************************************************************
/*
 * Domy�lnie kompilator generuje prolog i epilog dla ka�dej z funkcji.
 * Niestety - w tym dla funkcji main.
 * Dzi�ki u�yciu atrybutu naked kod ten nie zostanie wygenerowany.
 * Nie wolno u�ywa� tego atrybutu w innych funkcjach!!!
 * Wyst�puj� tutaj wyj�tki, ale nie b�dziemy si� nimi zajmowa�.
 */
int main (void) __attribute__ ((naked));
int main(void)
{
	initPeripherals();				//inicjalizujemy nasz uk�ad do pracy
	bLCDxy(0,1);
	bLCDpgmtext(PrzedstawSie1);
	bLCDxy(0,2);
	bLCDpgmtext(PrzedstawSie2);
	LCDdisplay(Freeze);				//Wysy�amy bufor obrazu do wy�wietlacza
	ReadSettings();					//odczytujemy ustawienia z EEPROM
	waitsek(1);
	/*
	 * Po uruchomieniu uk�adu od razu odczytujemy sobie zegar bez czekania na wyst�pienie
	 * przerwania od timera1. Po co? Bo odczytanymi danymi (dzie� tygodnia) indeksujemy
	 * tablic�, w kt�rej zapisane s� nazwy dni tygodnia.
	 */
	ICP_CompleteExt=true;
	while(1)
	{
		wdt_reset();				//reset uk�adu watchdog
		SysTick();					//obs�uga timer�w programowych
		RTCtask();					//obs�uga zegara DS3231
	/*
	 * Tutaj obs�ugujemy przebywanie w menu
	 */
		MenuProcess();
	/*
	 * Tutaj umieszczamy funkcje takie jak np. wy�wietlanie normalnego
	 * okna z komunikatami.
	 * Funkcje te przestan� by� wykonywane natychmiast po wci�ni�ciu klawisza OK.
	 * Zostawi�em sobie jednak ko�o awaryjne w postaci zmiennej inMenu.
	 * Ona ustawiona jest dopiero po poprawnym wej�ciu do menu.
	 * Dzi�ki temu w wyniku przypadkowego naci�ni�cia OK nie spowoduj� np.
	 * wy��czenia obs�ugi wyj��.
	 */
		if(wyswietlaniePozaMenu)
		{
			wyswietlanieNaLCD();		//
		}
		if(!inMenu)
		{
			;
		}
		sterowanieWyjsc();			//
	/*
	 * Naturalnie pisz�c funkcje umieszczone w pliku main mo�emy odwo�ywa� si�
	 * bezpo�rednio do zmiennej L_buzz. I np. informowa� u�ytkownika o jakiej�
	 * awarii itp.
	 */
		if(MenuWlaczBuzzer)
		{
			if(!L_buzz)L_buzz=1;
			MenuWlaczBuzzer=false;
		}
		buzzer();					//obs�uga buzzera
		/*
		 * Funkcj� przepisania bufora obrazu do LCD zwykle umieszczam jako
		 * wywo�ywan� na ko�cu, ze zwgl�du na mo�liwo�� wielokrotnego dost�pu do
		 * bufora obrazu przez r�ne funkcje, np. generowanie animacji itp.
		 */
		LCDdisplay(Clear);			//Wysy�amy bufor obrazu do wy�wietlacza
	/*
	 * Tutaj restartujemy nasze urz�dzenie.
	 */
		ProceduraRestartu();
	}
}

// TWI begin obs�uga TWI przy wykorzystaniu przerwa� na bazie AVR315

/****************************************************************************
Call this function to test if the TWI_ISR is busy transmitting.
****************************************************************************/
unsigned char TWI_Transceiver_Busy( void )
{
  return ( TWCR & (1<<TWIE) );                  // IF TWI Interrupt is enabled then the Transceiver is busy
}

/****************************************************************************
Call this function to fetch the state information of the previous operation. The function will hold execution (loop)
until the TWI_ISR has completed with the previous operation. If there was an error, then the function 
will return the TWI State code. 
****************************************************************************/
unsigned char TWI_Get_State_Info( void )
{
  while ( TWI_Transceiver_Busy() );             // Wait until TWI has completed the transmission.
  return ( TWI_state );                         // Return error state.
}

/****************************************************************************
Call this function to send a prepared message. The first byte must contain the slave address and the
read/write bit. Consecutive bytes contain the data to be sent, or empty locations for data to be read
from the slave. Also include how many bytes that should be sent/read including the address byte.
The function will hold execution (loop) until the TWI_ISR has completed with the previous operation,
then initialize the next operation and return.
****************************************************************************/
void TWI_Start_Transceiver_With_Data( unsigned char *msg, unsigned char msgSize )
{
  unsigned char temp;

  while ( TWI_Transceiver_Busy() );             // Wait until TWI is ready for next transmission.

  TWI_msgSize = msgSize;                        // Number of data to transmit.
  TWI_buf[0]  = msg[0];                         // Store slave address with R/W setting.
  if (!( msg[0] & (TRUE<<TWI_READ_BIT) ))       // If it is a write operation, then also copy data.
  {
    for ( temp = 1; temp < msgSize; temp++ )
      TWI_buf[ temp ] = msg[ temp ];
  }
  TWI_statusReg.all = 0;      
  TWI_state         = TWI_NO_STATE ;
  TWCR = (1<<TWEN)|                             // TWI Interface enabled.
         (1<<TWIE)|(1<<TWINT)|                  // Enable TWI Interrupt and clear the flag.
         (0<<TWEA)|(1<<TWSTA)|(0<<TWSTO)|       // Initiate a START condition.
         (0<<TWWC);                             //
}

// ********** Interrupt Handler ********** //
/****************************************************************************
This function is the Interrupt Service Routine (ISR), and called when the TWI interrupt is triggered;
that is whenever a TWI event has occurred. This function should not be called directly from the main
application.
****************************************************************************/
ISR(TWI_vect)
{
	static unsigned char TWI_bufPtr;
	switch (TWSR)
	{
		case TWI_START:             // START has been transmitted
		case TWI_REP_START:         // Repeated START has been transmitted
		TWI_bufPtr = 0;                                     // Set buffer pointer to the TWI Address location
		case TWI_MTX_ADR_ACK:       // SLA+W has been tramsmitted and ACK received
		case TWI_MTX_DATA_ACK:      // Data byte has been tramsmitted and ACK received
		if (TWI_bufPtr < TWI_msgSize)
		{
			TWDR = TWI_buf[TWI_bufPtr++];
			TWCR = (1<<TWEN)|                                 // TWI Interface enabled
			(1<<TWIE)|(1<<TWINT)|                      // Enable TWI Interupt and clear the flag to send byte
			(0<<TWEA)|(0<<TWSTA)|(0<<TWSTO)|           //
			(0<<TWWC);                                 //
		}else                    // Send STOP after last byte
		{
			TWI_statusReg.lastTransOK = TRUE;                 // Set status bits to completed successfully.
			TWCR = (1<<TWEN)|                                 // TWI Interface enabled
			(0<<TWIE)|(1<<TWINT)|                      // Disable TWI Interrupt and clear the flag
			(0<<TWEA)|(0<<TWSTA)|(1<<TWSTO)|           // Initiate a STOP condition.
			(0<<TWWC);                                 //
		}
		break;
		case TWI_MRX_DATA_ACK:      // Data byte has been received and ACK tramsmitted
		TWI_buf[TWI_bufPtr++] = TWDR;
		case TWI_MRX_ADR_ACK:       // SLA+R has been tramsmitted and ACK received
		if (TWI_bufPtr < (TWI_msgSize-1) )                  // Detect the last byte to NACK it.
		{
			TWCR = (1<<TWEN)|                                 // TWI Interface enabled
			(1<<TWIE)|(1<<TWINT)|                      // Enable TWI Interupt and clear the flag to read next byte
			(1<<TWEA)|(0<<TWSTA)|(0<<TWSTO)|           // Send ACK after reception
			(0<<TWWC);                                 //
		}else                    // Send NACK after next reception
		{
			TWCR = (1<<TWEN)|                                 // TWI Interface enabled
			(1<<TWIE)|(1<<TWINT)|                      // Enable TWI Interupt and clear the flag to read next byte
			(0<<TWEA)|(0<<TWSTA)|(0<<TWSTO)|           // Send NACK after reception
			(0<<TWWC);                                 //
		}
		break;
		case TWI_MRX_DATA_NACK:     // Data byte has been received and NACK tramsmitted
		TWI_buf[TWI_bufPtr] = TWDR;
		TWI_statusReg.lastTransOK = TRUE;                 // Set status bits to completed successfully.
		TWCR = (1<<TWEN)|                                 // TWI Interface enabled
		(0<<TWIE)|(1<<TWINT)|                      // Disable TWI Interrupt and clear the flag
		(0<<TWEA)|(0<<TWSTA)|(1<<TWSTO)|           // Initiate a STOP condition.
		(0<<TWWC);                                 //
		break;
		case TWI_ARB_LOST:          // Arbitration lost
		TWCR = (1<<TWEN)|                                 // TWI Interface enabled
		(1<<TWIE)|(1<<TWINT)|                      // Enable TWI Interupt and clear the flag
		(0<<TWEA)|(1<<TWSTA)|(0<<TWSTO)|           // Initiate a (RE)START condition.
		(0<<TWWC);                                 //
		break;
		case TWI_MTX_ADR_NACK:      // SLA+W has been tramsmitted and NACK received
		case TWI_MRX_ADR_NACK:      // SLA+R has been tramsmitted and NACK received
		case TWI_MTX_DATA_NACK:     // Data byte has been tramsmitted and NACK received
		//    case TWI_NO_STATE              // No relevant state information available; TWINT = �0�
		case TWI_BUS_ERROR:         // Bus error due to an illegal START or STOP condition
		default:
		TWI_state = TWSR;                                 // Store TWSR and automatically sets clears noErrors bit.
		// Reset TWI Interface
		TWCR = (1<<TWEN)|                                 // Enable TWI-interface and release TWI pins
		(0<<TWIE)|(1<<TWINT)|                      // Disable Interupt
		(0<<TWEA)|(0<<TWSTA)|(0<<TWSTO);           // No Signal requests
	}
}
// TWI end
